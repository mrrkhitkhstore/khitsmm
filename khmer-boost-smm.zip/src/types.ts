/**
 * Khmer Boost SMM Types and Translation Dictionary
 */

export interface SMMService {
  id: string;
  category: "facebook" | "tiktok" | "telegram" | "youtube" | "all";
  nameEn: string;
  nameKm: string;
  rateEn: number; // Price per 1000 in USD
  minQuantity: number;
  maxQuantity: number;
  descriptionEn: string;
  descriptionKm: string;
  platform: "Facebook" | "TikTok" | "Telegram" | "YouTube";
}

export interface SMMOrder {
  id: string;
  userId: string;
  userEmail: string;
  serviceId: string;
  serviceName: string;
  platform: string;
  link: string;
  quantity: number;
  charge: number;
  status: "pending" | "processing" | "completed" | "canceled";
  createdAt: string;
}

export interface UserSession {
  id: string;
  email: string;
  username: string;
  balance: number;
  role: "user" | "admin";
  createdAt: string;
}

export interface Transaction {
  id: string;
  userId: string;
  userEmail: string;
  amount: number;
  bank: "aba" | "acleda" | "wing";
  transactionId: string;
  status: "pending" | "approved" | "rejected";
  createdAt: string;
}

export interface SupportMessage {
  id: string;
  userId: string;
  userEmail: string;
  subject: string;
  message: string;
  status: "open" | "answered";
  reply?: string;
  createdAt: string;
}

export const KhmerSMMTranslations = {
  en: {
    brandName: "KHMER BOOST SMM",
    tagline: "Cambodia's #1 Social Media Booster Panel",
    description: "Instantly elevate your social presence on Facebook, TikTok, Telegram, and YouTube. Trust the fastest, most reliable, and beautifully secure SMM Panel in Cambodia with instant auto-services.",
    heroActionBuy: "Get Started",
    heroActionServices: "View Services",
    heroStatsUsers: "Active Boosters",
    heroStatsCompleted: "Orders Processed",
    heroStatsRating: "Customer Satisfaction",
    
    // Nav Items
    navHome: "Home",
    navServices: "Services",
    navLogin: "Login",
    navRegister: "Register",
    navDashboard: "Dashboard",
    navOrders: "My Orders",
    navAddFunds: "Add Funds",
    navApi: "API Documentation",
    navContact: "Contact Support",
    navAdmin: "Admin Console",
    navLogout: "Log Out",

    // Auth
    authWelcomeBack: "Welcome Back",
    authSlogan: "Boost your social growth effortlessly",
    authEmail: "Email Address",
    authUsername: "Username",
    authPassword: "Password",
    authConfirmPassword: "Confirm Password",
    authForgotPassword: "Forgot password?",
    authResetPassword: "Reset Password",
    authNoAccount: "Don't have an account yet?",
    authHaveAccount: "Already have an account?",
    authSignUpBtn: "Create Free Account",
    authSignInBtn: "Sign In Security",
    authFormErrors: "Please fill all fields correctly.",
    authPassMismatch: "Passwords do not match.",

    // Dashboard
    dashWelcome: "Hello, booster!",
    dashSlogan: "Let's fuel your digital presence today.",
    dashCurrentBalance: "Current Balance",
    dashNewOrder: "New Promotion Order",
    dashOrderCategory: "Select Platform",
    dashOrderService: "Select Service Type",
    dashTargetLink: "Target Profile or Video Link",
    dashQuantity: "Transfer Quantity",
    dashRatePer1000: "Price per 1000 units",
    dashTotalCharge: "Total Order Cost",
    dashPlaceOrderBtn: "Launch Boost Order",
    dashMinMax: "Min: {min} | Max: {max}",
    dashInstantDelivery: "⚡ Automatic Instant Processing Starts Instantly",
    dashOrderSuccess: "🎉 Order placed successfully! The SMM pipeline is running.",
    dashBalanceErr: "❌ Insufficient balance. Please refill your deposit funds.",
    dashGenericErr: "Something went wrong. Please check your session.",

    // Table headers
    thOrderId: "Order ID",
    thService: "SMM Service Unit",
    thLink: "Target Link URL",
    thQuantity: "Qty",
    thCharge: "Cost",
    thStatus: "Boost Status",
    thDate: "Registration Date",

    // Services Page
    servTitle: "Available SMM Catalogs",
    servSub: "Highly optimized promotion server speeds with precise targeting options.",
    servPlatform: "Platform Selector",
    servRate: "Rate per 1000",
    servMinMaxShort: "Min / Max Capacity",

    // Payments page
    payTitle: "Add Deposit Funds",
    paySub: "Refill your credit safely. Balance is updated within 1-5 minutes.",
    paySelectBank: "1. Select Payment gateway",
    payAbaDesc: "Instantly process transfers with Cambodia's leading banking provider.",
    payAcledaDesc: "Trusted national ACLEDA QR scan transfer infrastructure.",
    payWingDesc: "Fast and lightweight Wing wallet digital transactions.",
    payScanQr: "2. Scan KHQR Code via App",
    payAbaInstructions: "Open your ABA bank app, tap SCAN, point to the QR code, review the account name, and input the precise transfer amount.",
    payAcledaInstructions: "Open ACLEDA Mobile app, scan the KHQR code below, input the payment amount, and proceed securely.",
    payWingInstructions: "Use Wing Money wallet application. Tap Scan QR, check details, input exact funding amount, and verify.",
    payEnterDetails: "3. Submit Transaction Reference",
    payFormAmount: "Sent Amount ($ USD)",
    payFormTxId: "Transaction TXID / Reference String",
    payFormSubmitBtn: "Confirm Payment Receipt",
    paySuccessSubmitted: "✅ Transaction submitted. Admin is reviewing your deposit.",
    payFormErr: "Please fill out all payment receipts fields.",

    // API Page
    apiTitle: "SMM Integration API Docs",
    apiSub: "Connect your reseller portal, software tool, or website. Seamless automatic JSON REST routes.",
    apiEndpoints: "Available Endpoints",
    apiParamTable: "Parameter Rules",
    apiResponseSample: "Output Sample Response",

    // Support Page
    supTitle: "Contact Technical Support",
    supSub: "We are available 24/7 to resolve loading issues, pending transactions, or large project quotes.",
    supSubject: "Topic Subject",
    supMessage: "How can our engineers assist you?",
    supSubmitBtn: "Send Technical Ticket",
    supSuccess: "📬 Ticket received. Our staff will contact you via your login email, check below for immediate updates.",
    supNoTickets: "No active discussions created. Open a ticket when needed.",
    supResponseTitle: "Technical Support Resolution History",

    // Reviews section
    revTitle: "Trusted by Top Creators",
    revSub: "See why Cambodia's entrepreneurs, streamers, and businesses rely on Khmer Boost SMM.",
    
    // FAQ
    faqTitle: "Frequently Answered Questions",
    faqSub: "Understand how SMM boosts work, payment terms, and maximum project safety rules.",

    // Footer
    footText: "Khmer Boost SMM offers state-of-the-art social media boost interfaces with unmatched service velocity. Enjoy the finest glassmorphic dashboard built in Cambodia.",
    footLinks: "Useful Links",
    footSocial: "Connect With Us",
    
    // Common statuses
    statusPending: "Pending",
    statusProcessing: "Processing",
    statusCompleted: "Completed",
    statusCanceled: "Canceled",
    statusRejected: "Rejected",
    statusApproved: "Approved",

    // Admin Panel
    admTitle: "Admin Oversight Center",
    admSub: "Full command system over user budgets, orders, payment clearances, and catalogs.",
    admStatsUsers: "Total Client Base",
    admStatsOrders: "All Social Launches",
    admStatsVolume: "Financial Volume",
    admStatsPendTrans: "Pending KHQR Approvals",
    admUsersTab: "Clients Management",
    admOrdersTab: "Services Routing",
    admTransTab: "KHQR Verifications",
    admServicesTab: "SMM Catalogs",
    admAddBalance: "Refill Balance",
    admMakeAdmin: "Grant Admin permission",
    admRevokeAdmin: "Revoke Admin",
    admUserEmail: "User Email",
    admUserUsername: "Username",
    admUserRole: "Privilege",
    admUserBalance: "Usable Credits",
    admAction: "Actions",
    admApprove: "Approve Payment",
    admReject: "Reject Payment",
    admCreateService: "Create SMM Service Catalog",
    admServiceNameEn: "Service Name (English)",
    admServiceNameKm: "Service Name (Khmer)",
    admServiceCategory: "App Category",
    admServiceRate: "Price per 1000 ($ USD)",
    admServiceMin: "Minimum Units Limit",
    admServiceMax: "Maximum Units Limit",
    admServiceDescEn: "Bullet details (English)",
    admServiceDescKm: "Bullet details (Khmer)",
    admSaveBtn: "Save Service Item",
    admDeleteBtn: "Delete SMM Item",
    admEditBtn: "Edit Item"
  },
  km: {
    brandName: "KHMER BOOST SMM",
    tagline: "បន្ទះបង្កើនការណែនាំបណ្តាញសង្គមដ៏ធំជាងគេនៅកម្ពុជា",
    description: "បង្កើនវត្តមានបណ្តាញសង្គមរបស់អ្នកភ្លាមៗនៅលើ Facebook, TikTok, Telegram, និង YouTube។ ជឿជាក់លើប្រព័ន្ធ SMM Panel ដែលលឿនបំផុត គួរឱ្យទុកចិត្តបំផុត និងមានសុវត្ថិភាពខ្ពស់នៅកម្ពុជា ជាមួយសេវាកម្មដំណើរការដោយស្វ័យប្រវត្តិនាពេលបច្ចុប្បន្ន។",
    heroActionBuy: "ចាប់ផ្ដើមឥឡូវនេះ",
    heroActionServices: "មើលសេវាកម្មទាំងអស់",
    heroStatsUsers: "អ្នកប្រើប្រាស់សកម្ម",
    heroStatsCompleted: "ការបញ្ជាទិញបានសម្រេច",
    heroStatsRating: "ការពេញចិត្តរបស់អតិថិជន",
    
    // Nav Items
    navHome: "ទំព័រដើម",
    navServices: "សេវាកម្ម",
    navLogin: "ចូលគណនី",
    navRegister: "ចុះឈ្មោះ",
    navDashboard: "ផ្ទាំងគ្រប់គ្រង",
    navOrders: "ការបញ្ជាទិញរបស់ខ្ញុំ",
    navAddFunds: "បញ្ចូលប្រាក់",
    navApi: "ឯកសារភ្ជាប់ API",
    navContact: "ទាក់ទងគាំទ្រ",
    navAdmin: "បន្ទះអ្នកគ្រប់គ្រង",
    navLogout: "ចាកចេញ",

    // Auth
    authWelcomeBack: "ស្វាគមន៍មកវិញ",
    authSlogan: "បង្កើនការរីកចម្រើនបណ្តាញសង្គមរបស់អ្នកយ៉ាងងាយស្រួល",
    authEmail: "អាសយដ្ឋានអ៊ីមែល",
    authUsername: "ឈ្មោះអ្នកប្រើប្រាស់",
    authPassword: "លេខសម្ងាត់",
    authConfirmPassword: "បញ្ជាក់លេខសម្ងាត់",
    authForgotPassword: "ភ្លេចលេខសម្ងាត់?",
    authResetPassword: "កំណត់លេខសម្ងាត់ឡើងវិញ",
    authNoAccount: "មិនទាន់មានគណនីមែនទេ?",
    authHaveAccount: "មានគណនីរួចហើយមែនទេ?",
    authSignUpBtn: "បង្កើតគណនីឥតគិតថ្លៃ",
    authSignInBtn: "ចូលគណនីដោយសុវត្ថិភាព",
    authFormErrors: "សូមបំពេញព័ត៌មានឱ្យបានត្រឹមត្រូវ។",
    authPassMismatch: "លេខសម្ងាត់យល់ព្រមមិនត្រូវគ្នាទេ។",

    // Dashboard
    dashWelcome: "សួស្តី booster!",
    dashSlogan: "តោះមកជួយជំរុញទំព័របណ្តាញសង្គមរបស់អ្នកនៅថ្ងៃនេះ។",
    dashCurrentBalance: "សមតុល្យទឹកប្រាក់",
    dashNewOrder: "ការបញ្ជាទិញសេវាកម្មថ្មី",
    dashOrderCategory: "ជ្រើសរើសប្រភេទបណ្តាញ",
    dashOrderService: "ជ្រើសរើសសេវាកម្ម",
    dashTargetLink: "លីងគណនី ឬវីដេអូគោលដៅ",
    dashQuantity: "ចំនួនដែលចង់បាន",
    dashRatePer1000: "តម្លៃក្នុង ១,០០០ គ្រឿង",
    dashTotalCharge: "ទឹកប្រាក់ត្រូវទូទាត់សរុប",
    dashPlaceOrderBtn: "បញ្ជាទិញការជំរុញ Boost",
    dashMinMax: "យ៉ាងតិច: {min} | យ៉ាងច្រើន: {max}",
    dashInstantDelivery: "⚡ សេវាកម្មចាប់ផ្តើមដំណើរការភ្លាមៗដោយស្វ័យប្រវត្ត",
    dashOrderSuccess: "🎉 ការបញ្ជាទិញបានជោគជ័យ! ប្រព័ន្ធកំពុងដំណើរការជំរុញសេវាកម្មរបស់អ្នក។",
    dashBalanceErr: "❌ មិនមានទឹកប្រាក់គ្រប់គ្រាន់ទេ។ សូមបញ្ចូលប្រាក់បន្ថែមក្នុងគណនី។",
    dashGenericErr: "មានបញ្ហាអ្វីមួយ។ សូមពិនិត្យមើលការចូលគណនីរបស់អ្នកឡើងវិញ។",

    // Table headers
    thOrderId: "លេខទិញ",
    thService: "សេវាកម្មជំរុញបំប៉ន SMM",
    thLink: "លីងគោលដៅ",
    thQuantity: "ចំនួន",
    thCharge: "តម្លៃ",
    thStatus: "ស្ថានភាព Boost",
    thDate: "កាលបរិច្ឆេទ",

    // Services Page
    servTitle: "កាតាឡុកសេវាកម្ម SMM",
    servSub: "ល្បឿនម៉ាស៊ីនបម្រើជំរុញកម្រិតខ្ពស់ និងជម្រើសគោលដៅច្បាស់លាស់។",
    servPlatform: "អ្នកជ្រើសរើសវេទិកា",
    servRate: "តម្លៃក្នុង ១,០០០ គ្រឿង",
    servMinMaxShort: "ដែនកំណត់ តិច/ច្រើន",

    // Payments page
    payTitle: "បញ្ចូលទឹកប្រាក់បន្ថែម",
    paySub: "ផ្ទេរប្រាក់ដោយសុវត្ថិភាព។ សមតុល្យទទួលបានក្នុង ១ ទៅ ៥ នាទី។",
    paySelectBank: "១. ជ្រើសរើសធនាគារទូទាត់",
    payAbaDesc: "ទូទាត់ភ្លាមៗជាមួយធនាគារឈានមុខគេ ABA នៃប្រទេសកម្ពុជា។",
    payAcledaDesc: "ប្រព័ន្ធស្កេនទូទាត់ KHQR ជាតិដែលទុកចិត្តរបស់ អេស៊ីលីដា។",
    payWingDesc: "ទូទាត់រហ័សទាន់ចិត្តតាមរយៈកាបូបលុយ Wing Digital Wallet។",
    payScanQr: "២. ស្កេនកូដ KHQR តាមកម្មវិធីទូរស័ព្ទ",
    payAbaInstructions: "សូមបើកកម្មវិធីធនាគារ ABA របស់អ្នក រួចស្កេន (SCAN) លើកូដ QR ខាងក្រោម រួចផ្ទៀងផាត់ឈ្មោះគណនី និងបញ្ចូលចំនួនទឹកប្រាក់ដែលចង់បញ្ចូល។",
    payAcledaInstructions: "សូមបើកកម្មវិធីធនាគារអេស៊ីលីដាម៉ូបាល ស្កេន KHQR ខាងក្រោម បញ្ចូលចំនួនទឹកប្រាក់ និងបញ្ជាក់ការផ្ទេរ។",
    payWingInstructions: "សូមប្រើកម្មវិធី Wing Money រួចស្កេនលើកូដ QR ខាងក្រោម ពិនិត្យព័ត៌មាន និងបញ្ជាក់ទូទាត់ផ្ទេរប្រាក់។",
    payEnterDetails: "៣. ផ្ញើលេខសេចក្តីយោងប្រតិបត្តិការផ្ទេរលុយ",
    payFormAmount: "ចំនួនទឹកប្រាក់ផ្ញើ ($ USD)",
    payFormTxId: "លេខកូដប្រតិបត្តិការ (TXID) / លេខយោង",
    payFormSubmitBtn: "បញ្ជាក់ការផ្ទេរប្រាក់",
    paySuccessSubmitted: "✅ ព័ត៌មានត្រូវបានបញ្ជូនរួចហើយ។ ខាងអ្នកគ្រប់គ្រងកំពុងត្រួតពិនិត្យសមតុល្យរបស់អ្នក។",
    payFormErr: "សូមបំពេញព័ត៌មានប្រតិបត្តិការឱ្យបានសព្វគ្រប់។",

    // API Page
    apiTitle: "ឯកសារភ្ជាប់ API សម្រាប់ដៃគូ",
    apiSub: "ភ្ជាប់ប្រព័ន្ធរបស់អ្នក គេហទំព័របន្តលក់ ឬកម្មវិធីជាមួយផ្លូវបង្ហូរទិន្នន័យ JSON REST API ដោយស្វ័យប្រវត្តិ។",
    apiEndpoints: "ប្រភព URL បញ្ជូនទិន្នន័យ",
    apiParamTable: "បន្ទាត់លក្ខន្តិកៈតម្រូវការ",
    apiResponseSample: "គំរូទិន្នន័យចម្លើយតប",

    // Support Page
    supTitle: "ទាក់ទងក្រុមបច្ចេកទេស",
    supSub: "ពួកយើងត្រៀមខ្លួនជួយ ២៤ ម៉ោងលើ ២៤ ម៉ោង ដើម្បីដោះស្រាយបញ្ហាគណនី ការពន្យារផ្ទេរលុយ ឬគម្រោងធំៗ។",
    supSubject: "ប្រធានបទសាកសួរ",
    supMessage: "តើយើងអាចជួយអ្វីខ្លះដល់អ្នក?",
    supSubmitBtn: "ផ្ញើសំបុត្រទាក់ទង",
    supSuccess: "📬 សំបុត្របានផ្ញើទៅកាន់ក្រុមបច្ចេកទេស។ ពួកយើងនឹងទាក់ទងទៅគណនីអ៊ីមែលរបស់អ្នក។ មើលខាងក្រោមដើម្បីដឹងពីការឆ្លើយតប។",
    supNoTickets: "មិនទាន់មានការសន្ទនាសកម្មនៅឡើយទេ។ សូមបើកសំបុត្រថ្មីប្រសិនបើមានតម្រូវការ។",
    supResponseTitle: "ប្រវត្តិដំណោះស្រាយបច្ចេកទេស",

    // Reviews section
    revTitle: "ទំនុកចិត្តពីអ្នកបង្កើតមាតិកាកំពូលៗ",
    revSub: "យល់ដឹងពីមូលហេតុដែលសហគ្រិន Khmer កំពូលៗ ស្ទ្រីមម័រ និងអាជីវកម្មធំៗ ជ្រើសរើសប្រើប្រាស់ Khmer Boost SMM។",

    // FAQ
    faqTitle: "សំណួរដែលសួរញឹកញាប់",
    faqSub: "ស្វែងយល់អំពីដំណើរការជំរុញបំប៉ន SMM លក្ខខណ្ឌទូទាត់ប្រាក់ និងសុវត្ថិភាពគណនីខ្ពស់បំផុត។",

    // Footer
    footText: "Khmer Boost SMM ផ្តល់ជូននូវបច្ចេកវិទ្យាជំរុញបណ្តាញសង្គមដ៏ជឿនលឿនជាមួយល្បឿនដែលមិនធ្លាប់មាន។ រីករាយការប្រើប្រាស់បន្ទះគ្រប់គ្រងដ៏ស្រស់ស្អាតបង្កើតឡើងសម្រាប់ប្រជាជនកម្ពុជា។",
    footLinks: "តំណភ្ជាប់មានប្រយោជន៍",
    footSocial: "បណ្តាញទំនាក់ទំនងពួកយើង",

    // Common statuses
    statusPending: "កំពុងរង់ចាំ",
    statusProcessing: "កំពុងដំណើរការ",
    statusCompleted: "បានសម្រេច",
    statusCanceled: "បានបោះបង់",
    statusRejected: "បានបដិសេធ",
    statusApproved: "បានយល់ព្រម",

    // Admin Panel
    admTitle: "មជ្ឈមណ្ឌលត្រួតពិនិត្យអ្នកគ្រប់គ្រង",
    admSub: "ប្រព័ន្ធបញ្ជាពេញលេញលើ សមតុល្យសមាជិក ការបញ្ជាទិញ ការបញ្ជាក់ប្រាក់ និងតារាងសេវាកម្មជំរុញ។",
    admStatsUsers: "អតិថិជនសរុប",
    admStatsOrders: "គ្រប់ការបញ្ជាទិញទាំងអស់",
    admStatsVolume: "ទំហំលំហូរទឹកប្រាក់ផ្ទេរ",
    admStatsPendTrans: "ការទូទាត់កំពុងរង់ចាំបញ្ជាក់",
    admUsersTab: "គ្រប់គ្រងអតិថិជន",
    admOrdersTab: "គ្រប់គ្រងការបញ្ជាទិញ SMM",
    admTransTab: "ការផ្ទៀងផ្ទាត់ចំណូល KHQR",
    admServicesTab: "ការកែសម្រួលសេវាកម្ម",
    admAddBalance: "បញ្ចូលលុយបន្ថែម",
    admMakeAdmin: "តម្លើងជា Admin",
    admRevokeAdmin: "ដកភាពជា Admin",
    admUserEmail: "អ៊ីមែលសមាជិក",
    admUserUsername: "ឈ្មោះសមាជិក",
    admUserRole: "សិទ្ធិ",
    admUserBalance: "សមតុល្យដែលអាចប្រើបាន",
    admAction: "សកម្មភាព",
    admApprove: "យល់ព្រមការទូទាត់",
    admReject: "បដិសេធការផ្ទេរលុយ",
    admCreateService: "បង្កើតសេវាកម្មជំរុញ SMM ថ្មី",
    admServiceNameEn: "ឈ្មោះសេវាកម្ម (អង់គ្លេស)",
    admServiceNameKm: "ឈ្មោះសេវាកម្ម (ខ្មែរ)",
    admServiceCategory: "ប្រភេទបណ្តាញ",
    admServiceRate: "តម្លៃក្នុង ១,០០០ គ្រឿង ($ USD)",
    admServiceMin: "ចំនួនដែនកំណត់តិចបំផុត",
    admServiceMax: "ចំនួនដែនកំណត់ច្រើនបំផុត",
    admServiceDescEn: "ព័ត៌មានលម្អិត (អង់គ្លេស)",
    admServiceDescKm: "ព័ត៌មានលម្អិត (ខ្មែរ)",
    admSaveBtn: "រក្សាទុកសេវាកម្ម",
    admDeleteBtn: "លុបសេវាកម្ម",
    admEditBtn: "កែប្រែ"
  }
};
