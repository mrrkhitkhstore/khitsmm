import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { KhmerSMMTranslations, UserSession, SMMService } from "./types";
import LanguageSelector from "./components/LanguageSelector";
import LandingPage from "./components/LandingPage";
import APIDocsView from "./components/APIDocsView";
import AddFundsView from "./components/AddFundsView";
import MyOrdersView from "./components/MyOrdersView";
import ContactView from "./components/ContactView";
import DashboardView from "./components/DashboardView";
import LoginForm from "./components/LoginForm";
import AdminConsole from "./components/AdminConsole";
import { 
  Menu, X, Sparkles, Home, ShoppingCart, User, Database, Coins, 
  Terminal, ShieldCheck, LogOut, FileText, Send, MessageSquare, AlertCircle, HelpCircle, Star, ChevronsRight 
} from "lucide-react";

export default function App() {
  // Lang state: "en" | "km" (Defaults to "km" for local Cambodian presence)
  const [currentLang, setLang] = useState<"en" | "km">("km");
  
  // Navigation active view routing State
  const [activeView, setActiveView] = useState<"home" | "services" | "dashboard" | "orders" | "add-funds" | "api" | "contact" | "login" | "admin">("home");

  // Mobile drawer states
  const [menuOpen, setMenuOpen] = useState(false);

  // User auth state persistence
  const [userToken, setUserToken] = useState<string | null>(null);
  const [userSession, setUserSession] = useState<UserSession | null>(null);
  
  // Live services roster for independent services view page
  const [generalServices, setGeneralServices] = useState<SMMService[]>([]);
  const [servicesFilter, setServicesFilter] = useState<"all" | "facebook" | "tiktok" | "telegram" | "youtube">("all");

  // Chatbot floating widget states
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<Array<{ sender: "user" | "bot", text: string }>>([
    { sender: "bot", text: "សួស្តី! ខ្ញុំជាជំនួយការស្វ័យប្រវត្តរបស់ Khmer Boost SMM។ តើខ្ញុំអាចជួយលោកអ្នកអំពីការទិញ Boost ឬរបៀបបញ្ចូលទឹកប្រាក់បានដែរឬទេ? (Hello! How can I assist you with social boosts or KHQR deposits today?)" }
  ]);

  const t = KhmerSMMTranslations[currentLang];

  // Try to load token session from local storage on bootstrap
  useEffect(() => {
    const savedToken = localStorage.getItem("kboost_token");
    if (savedToken) {
      setUserToken(savedToken);
      fetchSession(savedToken);
    }
  }, []);

  // Fetch all active SMM services catalogs
  const fetchGeneralServicesCatalog = async () => {
    try {
      const res = await fetch("/api/services");
      if (res.ok) {
        setGeneralServices(await res.json());
      }
    } catch (err) {
      console.error("Failed to load catalog rosters", err);
    }
  };

  useEffect(() => {
    fetchGeneralServicesCatalog();
  }, []);

  // Sync profile details
  const fetchSession = async (token: string) => {
    try {
      const res = await fetch("/api/auth/me", {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUserSession(data.user);
      } else {
        // Clear invalid token
        handleLogout();
      }
    } catch (err) {
      console.error("Core session fetch error", err);
    }
  };

  const handleAuthSuccess = (session: { token: string; user: UserSession }) => {
    localStorage.setItem("kboost_token", session.token);
    setUserToken(session.token);
    setUserSession(session.user);
    setActiveView("dashboard"); // Automatically redirect user to Dashboard
  };

  const handleLogout = () => {
    localStorage.removeItem("kboost_token");
    setUserToken(null);
    setUserSession(null);
    setActiveView("home");
  };

  // Quick helper to verify and refresh user balance
  const handleBalanceRefresh = () => {
    if (userToken) {
      fetchSession(userToken);
    }
  };

  // Automated floating live chatbot resolution logic
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userText = chatInput.trim();
    const newMsgs = [...chatMessages, { sender: "user" as const, text: userText }];
    setChatMessages(newMsgs);
    setChatInput("");

    setTimeout(() => {
      let botResponse = "អរគុណសម្រាប់ការសាកសួរ! ក្រុមការងារបច្ចេកទេសនឹងទាក់ទងមកអ្នកតាមរយៈអ៊ីមែលភ្លាមៗ។ (Thank you! Our technical advisor will follow up via your login email immediately.)";
      
      const query = userText.toLowerCase();
      if (query.includes("aba") || query.includes("acleda") || query.includes("wing") || query.includes("fund") || query.includes("បញ្ចូល") || query.includes("qr")) {
        botResponse = currentLang === "en" 
          ? "For adding deposit funds, navigate to the 'Add Funds' panel. Select your bank gateway, scan the customized corporate KHQR, and submit your reference transaction TXID. Balance credits within 1 to 5 minutes!"
          : "សម្រាប់ការបញ្ចូលលុយបន្ថែម សូមធ្វើដំណើរទៅកាន់ទំព័រ 'បញ្ចូលប្រាក់'។ ជ្រើសរើសធនាគារ ស្កេនទូទាត់ KHQR រួចផ្ញើលេខយោងប្រតិបត្តិការ (TXID) មកកាន់ពួកយើង។ សមតុល្យទទួលបានក្នុង ១ ទៅ ៥ នាទី។";
      } else if (query.includes("fb") || query.includes("facebook") || query.includes("like") || query.includes("follow") || query.includes("follower")) {
        botResponse = currentLang === "en"
          ? "We offer Facebook page likes, profile followers, and video post boosters under standard high speeds. Place your launch order in the 'Dashboard' page!"
          : "ពួកយើងមានសេវាកម្មទំព័រហ្វេសប៊ុក (Likes) អ្នកតាមដានគណនី (Followers) និងជំរុញវីដេអូ។ សូមបញ្ជាទិញនៅលើទំព័រ 'ផ្ទាំងគ្រប់គ្រង'!";
      } else if (query.includes("tiktok") || query.includes("view") || query.includes("comment") || query.includes("tt")) {
        botResponse = currentLang === "en"
          ? "TikTok services catalog starts instantly! Delivery of active profile views and comment streams is algorithm-safe."
          : "សេវាកម្ម TikTok ចាប់ផ្ដើមភ្លាមៗឥតរង់ចាំ! ការជំរុញចំនួនទស្សនា និងមតិយោបល់គឺទទួលបានសុវត្ថិភាពខ្ពស់បំផុត។";
      } else if (query.includes("speed") || query.includes("slow") || query.includes("pending") || query.includes("យឺត")) {
        botResponse = currentLang === "en"
          ? "Most boosts initiate in 1 minute. If your order status is pending, make sure your social post is set to Public, or open a technical 'Support Ticket' so our engineers can expedite."
          : "រាល់ការបញ្ជាទិញចាប់ផ្ដើមក្នុងរយៈពេល ១នាទី។ ប្រសិនបើជួបបញ្ហាយឺតយ៉ាវ សូមធានាថាគណនីរបស់អ្នកចំហជាសាធារណៈ (Public) ឬបើក 'សំបុត្រសំណូមពរ' ដើម្បីឱ្យក្រុមបច្ចេកទេសជួយជំរុញបន្ថែមជួរមុនគេ។";
      }

      setChatMessages(prev => [...prev, { sender: "bot", text: botResponse }]);
    }, 1000);
  };

  return (
    <div id="fullstack-applet-root" className="min-h-screen flex flex-col font-sans overflow-x-hidden antialiased select-none relative bg-gradient-to-b from-[#020510] via-[#090b20] to-[#01030d]">
      
      {/* Dynamic Cosmic Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f293708_1px,transparent_1px),linear-gradient(to_bottom,#1f293708_1px,transparent_1px)] bg-[size:24px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none"></div>

      {/* 1. NAVIGATION HEADER */}
      <header id="main-navigation-navbar" className="sticky top-0 z-40 w-full bg-[#030712]/75 backdrop-blur-xl border-b border-white/5 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-20 flex items-center justify-between">
          
          {/* Logo Name */}
          <button 
            type="button" 
            onClick={() => setActiveView("home")} 
            className="flex items-center space-x-2.5 text-left cursor-pointer select-none group"
          >
            <div className="p-2.5 bg-gradient-to-br from-purple-600 via-indigo-600 to-indigo-800 rounded-xl text-white shadow-md shadow-purple-900/35 group-hover:scale-105 transition-all duration-300">
              <Sparkles size={20} className="text-white animate-pulse" />
            </div>
            <div>
              <span className="text-lg font-black tracking-widest font-display text-white text-glow">
                KHMER BOOST SMM
              </span>
              <div className="text-[9px] uppercase font-bold tracking-widest text-[#E31E24] mt-0.5 font-display">Cambodia SMM Prime</div>
            </div>
          </button>

          {/* Desktop Nav Items */}
          <nav className="hidden xl:flex items-center space-x-1.5 text-xs font-semibold">
            {/* General Guest Link */}
            <button 
              onClick={() => setActiveView("home")} 
              className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center space-x-1.5 ${activeView === "home" ? "bg-slate-900 text-white border border-slate-800" : "text-slate-400 hover:text-white"}`}
            >
              <Home size={14} />
              <span>{t.navHome}</span>
            </button>
            <button 
              onClick={() => {
                fetchGeneralServicesCatalog();
                setActiveView("services");
              }} 
              className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center space-x-1.5 ${activeView === "services" ? "bg-slate-900 text-white border border-slate-800" : "text-slate-400 hover:text-white"}`}
            >
              <Database size={14} />
              <span>{t.navServices}</span>
            </button>
            <button 
              onClick={() => setActiveView("api")} 
              className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center space-x-1.5 ${activeView === "api" ? "bg-slate-900 text-white border border-slate-800" : "text-slate-400 hover:text-white"}`}
            >
              <Terminal size={14} />
              <span>{t.navApi}</span>
            </button>

            {/* Authenticated Links only */}
            {userToken && userSession ? (
              <>
                <button 
                  onClick={() => setActiveView("dashboard")} 
                  className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center space-x-1.5 ${activeView === "dashboard" ? "bg-purple-600/10 text-purple-400 border border-purple-500/20" : "text-slate-350 hover:text-white"}`}
                >
                  <ShoppingCart size={14} className="text-purple-400" />
                  <span>{t.navDashboard}</span>
                </button>
                <button 
                  onClick={() => setActiveView("orders")} 
                  className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center space-x-1.5 ${activeView === "orders" ? "bg-slate-900 text-white border border-slate-850" : "text-slate-350 hover:text-white"}`}
                >
                  <FileText size={14} />
                  <span>{t.navOrders}</span>
                </button>
                <button 
                  onClick={() => setActiveView("add-funds")} 
                  className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center space-x-1.5 ${activeView === "add-funds" ? "bg-slate-900 text-white border border-slate-850" : "text-slate-350 hover:text-white"}`}
                >
                  <Coins size={14} />
                  <span>{t.navAddFunds}</span>
                </button>
                <button 
                  onClick={() => setActiveView("contact")} 
                  className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center space-x-1.5 ${activeView === "contact" ? "bg-slate-900 text-white border border-slate-850" : "text-slate-350 hover:text-white"}`}
                >
                  <MessageSquare size={14} />
                  <span>{t.navContact}</span>
                </button>

                {/* Secure ADMIN gate */}
                {userSession.role === "admin" && (
                  <button 
                    onClick={() => setActiveView("admin")} 
                    className={`px-4 py-2 rounded-xl border transition cursor-pointer flex items-center space-x-1.5 ${
                      activeView === "admin" 
                        ? "bg-red-500/10 text-rose-450 border-red-500/40" 
                        : "bg-red-950/15 border-red-900/10 text-rose-400 hover:bg-slate-900"
                    }`}
                  >
                    <ShieldCheck size={14} />
                    <span>{t.navAdmin}</span>
                  </button>
                )}
              </>
            ) : (
              <>
                <button 
                  onClick={() => setActiveView("login")} 
                  className="px-4 py-2 text-slate-400 hover:text-white cursor-pointer transition"
                >
                  {t.navLogin}
                </button>
                <button 
                  onClick={() => {
                    setActiveView("login");
                  }} 
                  className="px-5 py-2.5 bg-gradient-to-r from-purple-650 to-indigo-655 hover:from-purple-600 hover:to-indigo-600 border border-purple-500/20 text-white rounded-xl shadow-lg ring-1 ring-purple-500/10 cursor-pointer transition"
                >
                  {t.navRegister}
                </button>
              </>
            )}
          </nav>

          {/* Right Area: Language selection + Wallet Balance summary */}
          <div className="flex items-center space-x-4">
            
            {/* Wallet balance display widget on header */}
            {userToken && userSession && (
              <div id="quick-wallet-header" className="hidden lg:flex items-center space-x-2 bg-slate-950 p-1.5 px-3 rounded-xl border border-slate-850">
                <Coins size={14} className="text-purple-400" />
                <span className="text-[10px] uppercase font-bold text-slate-500">{t.dashCurrentBalance}:</span>
                <span className="text-xs font-black font-mono text-white">${userSession.balance.toFixed(2)}</span>
                <button 
                  className="p-1 hover:text-white text-slate-500 transition" 
                  onClick={handleBalanceRefresh}
                  title="Force wallet synchronization"
                >
                  <Menu size={10} className="rotate-90" />
                </button>
              </div>
            )}

            {/* Language Switch */}
            <LanguageSelector currentLang={currentLang} setLang={setLang} />

            {/* Logout actions */}
            {userToken && userSession && (
              <button
                type="button"
                onClick={handleLogout}
                className="hidden xl:flex p-2 bg-slate-950 hover:bg-slate-900 border border-slate-850 hover:text-white text-slate-400 rounded-xl transition cursor-pointer"
                title="Sign out of panel session securely"
              >
                <LogOut size={14} />
              </button>
            )}

            {/* Mobile dynamic Menu Trigger */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="xl:hidden p-2.5 bg-slate-950 border border-slate-850 rounded-xl text-slate-450 hover:text-white cursor-pointer"
            >
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>

        </div>
      </header>

      {/* 2. MOBILE DRAWER SIDEBAR NAVIGATION PANEL */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            id="mobile-drawer-overlay"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="xl:hidden fixed inset-x-0 top-20 z-30 bg-[#030712] border-b border-slate-850 p-6 space-y-6 flex flex-col font-sans select-none shadow-2xl"
          >
            
            {/* Balance banner inside drawer mapping */}
            {userToken && userSession && (
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-900 flex justify-between items-center">
                <div>
                  <div className="text-[10px] text-slate-500 font-extrabold uppercase tracking-wider">{t.dashCurrentBalance}</div>
                  <div className="text-lg font-black font-mono text-white mt-1">${userSession.balance.toFixed(3)} USD</div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    setActiveView("add-funds");
                  }}
                  className="px-3 py-1.5 bg-purple-600 text-white rounded-lg text-xs font-bold"
                >
                  + Deposit
                </button>
              </div>
            )}

            <div className="flex flex-col gap-2.5 text-xs font-black uppercase tracking-wider">
              <button
                onClick={() => {
                  setMenuOpen(false);
                  setActiveView("home");
                }}
                className={`py-3 text-left pl-3 rounded-lg ${activeView === "home" ? "bg-slate-900 text-white" : "text-slate-400"}`}
              >
                {t.navHome}
              </button>
              <button
                onClick={() => {
                  setMenuOpen(false);
                  fetchGeneralServicesCatalog();
                  setActiveView("services");
                }}
                className={`py-3 text-left pl-3 rounded-lg ${activeView === "services" ? "bg-slate-900 text-white" : "text-slate-400"}`}
              >
                {t.navServices}
              </button>
              <button
                onClick={() => {
                  setMenuOpen(false);
                  setActiveView("api");
                }}
                className={`py-3 text-left pl-3 rounded-lg ${activeView === "api" ? "bg-slate-900 text-white" : "text-slate-400"}`}
              >
                {t.navApi}
              </button>

              {userToken && userSession ? (
                <>
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setActiveView("dashboard");
                    }}
                    className={`py-3 text-left pl-3 rounded-lg ${activeView === "dashboard" ? "bg-slate-900 text-white" : "text-slate-400"}`}
                  >
                    {t.navDashboard}
                  </button>
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setActiveView("orders");
                    }}
                    className={`py-3 text-left pl-3 rounded-lg ${activeView === "orders" ? "bg-slate-900 text-white" : "text-slate-400"}`}
                  >
                    {t.navOrders}
                  </button>
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setActiveView("add-funds");
                    }}
                    className={`py-3 text-left pl-3 rounded-lg ${activeView === "add-funds" ? "bg-slate-900 text-white" : "text-slate-400"}`}
                  >
                    {t.navAddFunds}
                  </button>
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setActiveView("contact");
                    }}
                    className={`py-3 text-left pl-3 rounded-lg ${activeView === "contact" ? "bg-slate-900 text-white" : "text-slate-400"}`}
                  >
                    {t.navContact}
                  </button>

                  {userSession.role === "admin" && (
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        setActiveView("admin");
                      }}
                      className={`py-3 text-left pl-3 rounded-lg text-rose-450 ${activeView === "admin" ? "bg-slate-900 font-bold" : "text-rose-450"}`}
                    >
                      🛡️ {t.navAdmin}
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      handleLogout();
                    }}
                    className="py-3 text-left pl-3 text-rose-500"
                  >
                    {t.navLogout}
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setActiveView("login");
                    }}
                    className="py-3 text-left pl-3 text-slate-350"
                  >
                    {t.navLogin}
                  </button>
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setActiveView("login");
                    }}
                    className="py-3 text-left pl-3 text-purple-400"
                  >
                    {t.navRegister}
                  </button>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3. CORE ROUTING CONTEXT PORT */}
      <main id="app-view-viewport" className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-6 py-8 relative">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeView}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.2 }}
            className="w-full h-full"
          >
            {/* VIEW ROUTING SELECTION */}
            {activeView === "home" && (
              <LandingPage 
                currentLang={currentLang} 
                onNavigateToRegister={() => setActiveView("login")} 
                onNavigateToLogin={() => setActiveView("login")} 
                onNavigateToServices={() => {
                  fetchGeneralServicesCatalog();
                  setActiveView("services");
                }} 
              />
            )}

            {activeView === "services" && (
              <div id="general-catalog-route-page" className="space-y-8 pb-12">
                <div className="p-6 rounded-2xl glass-panel relative overflow-hidden">
                  <div className="absolute top-0 right-0 h-40 w-40 bg-purple-500/10 rounded-full blur-3xl pointer-events-none"></div>
                  <h1 className="text-2xl font-bold font-display text-white">{t.servTitle}</h1>
                  <p className="text-sm text-slate-400 mt-1">{t.servSub}</p>
                </div>

                {/* Categories Tab selectors */}
                <div className="flex flex-wrap items-center gap-2">
                  {[
                    { id: "all", label: currentLang === "en" ? "All Catalogs" : "ទាំងអស់" },
                    { id: "facebook", label: "Facebook" },
                    { id: "tiktok", label: "TikTok" },
                    { id: "telegram", label: "Telegram" },
                    { id: "youtube", label: "YouTube" }
                  ].map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setServicesFilter(f.id as any)}
                      className={`px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer border ${
                        servicesFilter === f.id
                          ? "bg-purple-600/15 border-purple-500/40 text-purple-400 shadow-md"
                          : "bg-slate-950/50 hover:bg-slate-900 border-slate-900 text-slate-400 hover:text-white"
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>

                {/* Grid Lists layout */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {generalServices
                    .filter(s => servicesFilter === "all" || s.category === servicesFilter)
                    .map((item) => (
                      <div key={item.id} className="p-5 rounded-2xl glass-panel relative border border-slate-900 hover:border-slate-800 transition glow-border flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start gap-4">
                            <span className="px-2 py-0.5 text-[8px] font-black tracking-widest text-[#E31E24] bg-red-500/10 rounded uppercase">
                              {item.platform}
                            </span>
                            <span className="text-xs font-bold font-mono text-purple-400">ID: {item.id}</span>
                          </div>

                          <h3 className="text-sm font-extrabold text-slate-100 mt-3 font-display">
                            {currentLang === "en" ? item.nameEn : item.nameKm}
                          </h3>

                          <p className="text-xs text-slate-400 leading-relaxed font-sans mt-2">
                            {currentLang === "en" ? item.descriptionEn : item.descriptionKm}
                          </p>
                        </div>

                        {/* Lower Pricing info metadata */}
                        <div className="mt-6 pt-4 border-t border-slate-900/60 flex items-center justify-between">
                          <div>
                            <div className="text-xs font-black font-mono text-emerald-450">${item.rateEn.toFixed(3)}</div>
                            <div className="text-[8px] text-slate-500 font-bold uppercase tracking-wider mt-0.5">{t.servRate}</div>
                          </div>
                          <div>
                            <div className="text-[10px] font-mono text-slate-400 font-medium">Min: {item.minQuantity} | Max: {item.maxQuantity}</div>
                            <div className="text-[8px] text-slate-500 font-bold uppercase tracking-wider text-right mt-0.5">{t.servMinMaxShort}</div>
                          </div>
                        </div>

                        <div className="pt-4">
                          <button
                            onClick={() => {
                              if (userToken) {
                                setActiveView("dashboard");
                              } else {
                                setActiveView("login");
                              }
                            }}
                            className="w-full py-2 bg-slate-950 border border-slate-900 hover:border-slate-850 hover:text-purple-400 transition text-[10px] font-bold rounded-xl flex items-center justify-center space-x-1 cursor-pointer"
                          >
                            <span>{currentLang === "en" ? "Purchase Package" : "ទិញកញ្ចប់សេវាកម្ម"}</span>
                            <ChevronsRight size={10} />
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            )}

            {activeView === "login" && (
              <LoginForm 
                currentLang={currentLang} 
                onAuthSuccess={handleAuthSuccess} 
              />
            )}

            {activeView === "dashboard" && userToken && (
              <DashboardView 
                currentLang={currentLang}
                userToken={userToken}
                userBalance={userSession?.balance || 0}
                triggerBalanceRefresh={handleBalanceRefresh}
                onNavigateToFunds={() => setActiveView("add-funds")}
              />
            )}

            {activeView === "orders" && userToken && (
              <MyOrdersView 
                currentLang={currentLang}
                userToken={userToken}
              />
            )}

            {activeView === "add-funds" && userToken && (
              <AddFundsView 
                currentLang={currentLang}
                userToken={userToken}
                userBalance={userSession?.balance || 0}
                triggerBalanceRefresh={handleBalanceRefresh}
              />
            )}

            {activeView === "api" && (
              <APIDocsView currentLang={currentLang} />
            )}

            {activeView === "contact" && userToken && (
              <ContactView 
                currentLang={currentLang}
                userToken={userToken}
              />
            )}

            {activeView === "admin" && userToken && userSession?.role === "admin" && (
              <AdminConsole 
                currentLang={currentLang}
                userToken={userToken}
              />
            )}

          </motion.div>
        </AnimatePresence>
      </main>

      {/* 4. FLOATING SUPPORT CHATBOT WIDGET */}
      <div id="floating-chat-anchor" className="fixed bottom-6 right-6 z-50 font-sans">
        <AnimatePresence>
          {chatOpen && (
            <motion.div
              id="chatbot-interface-box"
              initial={{ opacity: 0, scale: 0.9, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 10 }}
              className="w-80 h-96 bg-[#0c0f24] border border-purple-500/20 rounded-2xl shadow-2xl flex flex-col justify-between overflow-hidden mb-4"
            >
              {/* Chat Header */}
              <div className="p-4 bg-purple-600/10 border-b border-purple-500/10 flex justify-between items-center bg-slate-950">
                <div className="flex items-center space-x-2.5">
                  <div className="p-1.5 bg-purple-600 rounded-lg text-white">
                    <Sparkles size={14} className="animate-spin text-white" />
                  </div>
                  <div>
                    <h4 className="text-xs font-extrabold text-white font-display tracking-tight">KBoost Support Bot</h4>
                    <span className="text-[8px] font-black text-green-400 flex items-center space-x-1 uppercase">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-400 inline-block animate-ping mr-1"></span>
                      <span>Online Assistant</span>
                    </span>
                  </div>
                </div>
                <button 
                  onClick={() => setChatOpen(false)} 
                  className="text-slate-400 hover:text-white cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Chat Thread message lists */}
              <div className="flex-1 p-3.5 space-y-3.5 overflow-y-auto text-xs bg-slate-950/20 select-text font-sans">
                {chatMessages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                    <div className={`p-3 max-w-[80%] rounded-2xl text-[11px] leading-relaxed select-text font-medium ${
                      msg.sender === "user"
                        ? "bg-purple-650 text-white rounded-br-none"
                        : "bg-slate-900 border border-slate-800 text-slate-300 rounded-bl-none"
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
              </div>

              {/* Chat action input send form */}
              <form onSubmit={handleSendMessage} className="p-2.5 bg-slate-950 border-t border-purple-500/10 flex gap-1.5 items-center">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder={currentLang === "en" ? "Ask about ABA QR, Tiktok, speed..." : "សួរដេញដោលអំពីការស្កេន, ល្បឿន TikTok..."}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-[11px] text-white focus:outline-none"
                />
                <button
                  type="submit"
                  className="p-2.5 bg-purple-600 text-white hover:bg-purple-500 rounded-xl transition cursor-pointer"
                >
                  <Send size={12} />
                </button>
              </form>

            </motion.div>
          )}
        </AnimatePresence>

        {/* Dynamic Float Circular Bubble Button */}
        <button
          onClick={() => setChatOpen(!chatOpen)}
          className="p-4 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-xl shadow-purple-950/45 cursor-pointer transition transform active:scale-95 duration-200 border border-purple-400/25 flex items-center justify-center float-right"
          title="Open Help Instant Chat"
        >
          {chatOpen ? <X size={20} /> : <MessageSquare size={20} />}
        </button>
      </div>

    </div>
  );
}
