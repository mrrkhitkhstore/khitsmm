import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { KhmerSMMTranslations, Transaction } from "../types";
import { CreditCard, QrCode, Coins, CheckCircle, ArrowRight, AlertCircle, Copy, Check } from "lucide-react";

interface AddFundsViewProps {
  currentLang: "en" | "km";
  userToken: string;
  userBalance: number;
  triggerBalanceRefresh: () => void;
}

export default function AddFundsView({ currentLang, userToken, userBalance, triggerBalanceRefresh }: AddFundsViewProps) {
  const t = KhmerSMMTranslations[currentLang];
  
  const [selectedBank, setSelectedBank] = useState<"aba" | "acleda" | "wing">("acleda");
  const [acledaSubMethod, setAcledaSubMethod] = useState<"company" | "personal">("company");
  const [depositAmount, setDepositAmount] = useState<string>("10");
  const [txId, setTxId] = useState<string>("");
  const [myTransactions, setMyTransactions] = useState<Transaction[]>([]);
  
  const [loading, setLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errMsg, setErrMsg] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Load user transactions list
  const fetchMyTransactions = async () => {
    try {
      const res = await fetch("/api/transactions/my", {
        headers: { Authorization: `Bearer ${userToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setMyTransactions(data);
      }
    } catch (err) {
      console.error("Error reading transaction vouchers", err);
    }
  };

  useEffect(() => {
    fetchMyTransactions();
  }, [userToken]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Submit Voucher Payment receipt handler
  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrMsg(null);
    setIsSuccess(false);

    const amt = parseFloat(depositAmount);
    if (!depositAmount || isNaN(amt) || amt <= 0) {
      setErrMsg(currentLang === "en" ? "Specify a valid numeric deposit amount." : "សូមអនុញ្ញាតបញ្ជាក់ចំនួនទឹកប្រាក់ទូទាត់ឲ្យបានត្រឹមត្រូវ។");
      return;
    }

    if (!txId.trim()) {
      setErrMsg(currentLang === "en" ? "Reference core transaction ID is required." : "សូមបញ្ជូនលេខយោងសម្គាល់ប្រតិបត្តិការឱ្យបានហ្មត់ចត់។");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/transactions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`
        },
        body: JSON.stringify({
          amount: amt,
          bank: selectedBank,
          transactionId: txId.trim()
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setErrMsg(data.error || "An error occurred submitting payment.");
      } else {
        setIsSuccess(true);
        setTxId("");
        fetchMyTransactions();
        triggerBalanceRefresh();
      }
    } catch (err) {
      setErrMsg("Network failure. Please retry later.");
    } finally {
      setLoading(false);
    }
  };

  // Bank Info details helper
  const bankConfig = {
    aba: {
      accountName: "KHMER BOOST SMM CO., LTD",
      accountNumber: "005 601 292",
      color: "from-teal-600 to-cyan-800",
      accent: "text-teal-400",
      bgHex: "#0D2C54"
    },
    acleda: {
      accountName: acledaSubMethod === "company" ? "KHMER BOOST SMM TRADING" : "ACLEDA Account (Personal)",
      accountNumber: acledaSubMethod === "company" ? "3490-255-882" : "086978830",
      color: "from-yellow-600 to-amber-800",
      accent: "text-amber-400",
      bgHex: "#392A16"
    },
    wing: {
      accountName: "KHMER BOOST SMM WING",
      accountNumber: "0962383829",
      color: "from-lime-600 to-emerald-800",
      accent: "text-lime-400",
      bgHex: "#1B2A10"
    }
  };

  const amountVal = parseFloat(depositAmount) || 10;
  const refCode = `KBOOST-${userToken.substring(4, 9).toUpperCase()}`;
  let qrUrl = "";
  
  if (selectedBank === "aba") {
    const abaData = `https://pay.ababank.com/pay?name=KHMER BOOST SMM CO LTD&account=005601292&amount=${amountVal}&ref=${refCode}`;
    qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(abaData)}`;
  } else if (selectedBank === "wing") {
    const wingData = `https://wingmoney.com/pay?account=0962383829&amount=${amountVal}&ref=${refCode}`;
    qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(wingData)}`;
  } else {
    // ACLEDA
    const acledaData = acledaSubMethod === "company"
      ? `KHQR://acledabank.com.kh/pay?name=KHMER BOOST SMM TRADING&account=3490255882&amount=${amountVal}&currency=USD&ref=${refCode}`
      : `KHQR://acledabank.com.kh/pay?name=ACLEDA Personal&account=086978830&amount=${amountVal}&currency=USD&ref=${refCode}`;
    qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(acledaData)}`;
  }

  return (
    <div id="add-funds-container" className="space-y-8">
      {/* Page Header */}
      <div id="add-funds-header" className="p-6 rounded-2xl glass-panel relative overflow-hidden">
        <div className="absolute -top-12 -right-12 p-16 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative flex items-center space-x-3">
          <div className="p-3 bg-blue-500/15 rounded-xl text-blue-400">
            <Coins size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold font-display tracking-tight text-white">{t.payTitle}</h1>
            <p className="text-sm text-slate-400 mt-1">{t.paySub}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Left Column: Bank的选择 和 Verification Submission */}
        <div className="space-y-6">
          
          {/* Step 1: Select Bank API */}
          <div className="p-6 rounded-2xl glass-panel border border-slate-800/80">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 font-display mb-4">
              {t.paySelectBank}
            </h3>
            <div className="grid grid-cols-3 gap-3">
              {/* ABA Bank Button */}
              <button
                type="button"
                onClick={() => setSelectedBank("aba")}
                className={`p-4 rounded-xl flex flex-col items-center justify-center border transition-all text-center relative overflow-hidden cursor-pointer ${
                  selectedBank === "aba"
                    ? "bg-teal-500/10 border-teal-500/40 text-white shadow-lg"
                    : "bg-slate-950 border-slate-900 text-slate-400 hover:text-slate-300 hover:border-slate-800"
                }`}
              >
                <div className="font-extrabold text-sm tracking-widest font-display">ABA</div>
                <div className="text-[10px] text-slate-400 mt-1 font-medium">Bank QR</div>
                {selectedBank === "aba" && (
                  <div className="absolute top-1 right-1 w-2 h-2 rounded-full bg-teal-400"></div>
                )}
              </button>

              {/* ACLEDA Bank Button */}
              <button
                type="button"
                onClick={() => setSelectedBank("acleda")}
                className={`p-4 rounded-xl flex flex-col items-center justify-center border transition-all text-center relative overflow-hidden cursor-pointer ${
                  selectedBank === "acleda"
                    ? "bg-amber-500/10 border-amber-500/40 text-white shadow-lg"
                    : "bg-slate-950 border-slate-900 text-slate-400 hover:text-slate-300 hover:border-slate-800"
                }`}
              >
                <div className="font-extrabold text-sm tracking-widest font-display">ACLEDA</div>
                <div className="text-[10px] text-slate-400 mt-1 font-medium">KHQR</div>
                {selectedBank === "acleda" && (
                  <div className="absolute top-1 right-1 w-2 h-2 rounded-full bg-amber-400"></div>
                )}
              </button>

              {/* Wing Wallet Button */}
              <button
                type="button"
                onClick={() => setSelectedBank("wing")}
                className={`p-4 rounded-xl flex flex-col items-center justify-center border transition-all text-center relative overflow-hidden cursor-pointer ${
                  selectedBank === "wing"
                    ? "bg-lime-500/10 border-lime-500/40 text-white shadow-lg"
                    : "bg-slate-950 border-slate-900 text-slate-400 hover:text-slate-300 hover:border-slate-800"
                }`}
              >
                <div className="font-extrabold text-sm tracking-widest font-display">WING</div>
                <div className="text-[10px] text-slate-400 mt-1 font-medium">Wallet</div>
                {selectedBank === "wing" && (
                  <div className="absolute top-1 right-1 w-2 h-2 rounded-full bg-lime-400"></div>
                )}
              </button>
            </div>

            {selectedBank === "acleda" && (
              <div className="mt-4 p-3.5 bg-slate-900/60 rounded-xl border border-slate-850/80 space-y-2.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-500 font-sans block">
                  {currentLang === "en" ? "Select ACLEDA Account Destination:" : "ជ្រើសរើសទម្រង់គណនីអេស៊ីលីដាទទួលយក៖"}
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAcledaSubMethod("company")}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold cursor-pointer text-center transition-all border ${
                      acledaSubMethod === "company"
                        ? "bg-amber-500/10 border-amber-500/40 text-white shadow-sm font-bold"
                        : "bg-slate-950 border-slate-900 text-slate-400 hover:text-slate-300 hover:border-slate-800"
                    }`}
                  >
                    {currentLang === "en" ? "Company KHQR" : "គណនីក្រុមហ៊ុន KHQR"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setAcledaSubMethod("personal")}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold cursor-pointer text-center transition-all border ${
                      acledaSubMethod === "personal"
                        ? "bg-amber-500/10 border-amber-500/40 text-white shadow-sm font-bold"
                        : "bg-slate-950 border-slate-900 text-slate-400 hover:text-slate-300 hover:border-slate-800"
                    }`}
                  >
                    {currentLang === "en" ? "Personal Account" : "គណនីផ្ទាល់ខ្លួន"}
                  </button>
                </div>
              </div>
            )}

            <p className="text-xs text-slate-400 mt-4 leading-relaxed">
              {selectedBank === "aba" && t.payAbaDesc}
              {selectedBank === "acleda" && (acledaSubMethod === "company" ? t.payAcledaDesc : (currentLang === "en" ? "Direct personal transfer to ACLEDA Mobile number 086978830 with instant confirmation." : "ផ្ទេរប្រាក់ផ្ទាល់ខ្លួនដោយផ្ទាល់ទៅលេខទូរស័ព្ទ អេស៊ីលីដាម៉ូបាល ០៨៦៩៧៨៨៣០ ជាមួយការបញ្ជាក់រហ័ស។"))}
              {selectedBank === "wing" && t.payWingDesc}
            </p>
          </div>

          {/* Step 3: Submission Details */}
          <div className="p-6 rounded-2xl glass-panel border border-slate-800">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 font-display mb-4">
              {t.payEnterDetails}
            </h3>

            <form onSubmit={handlePaymentSubmit} className="space-y-4">
              
              {/* Deposit amount input box */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                  {t.payFormAmount}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 font-bold font-mono">
                    $
                  </div>
                  <input
                    type="number"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                    placeholder="10.00"
                    min="1"
                    step="any"
                    className="w-full bg-slate-950 border border-slate-900 rounded-xl pl-9 pr-4 py-3 text-sm text-slate-100 font-mono focus:outline-none focus:border-purple-500 transition"
                  />
                </div>
                <div className="mt-1 flex gap-2">
                  {["10", "20", "50", "100", "250"].map((val) => (
                    <button
                      type="button"
                      key={val}
                      onClick={() => setDepositAmount(val)}
                      className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-850 hover:text-white border border-slate-850 text-[10px] font-mono text-slate-400 cursor-pointer"
                    >
                      +${val}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reference Transaction ID text field */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                  {t.payFormTxId}
                </label>
                <input
                  type="text"
                  value={txId}
                  onChange={(e) => setTxId(e.target.value)}
                  placeholder={selectedBank === "aba" ? "ABA012398457" : selectedBank === "acleda" ? "ACL05829392" : "WNG0937482"}
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-3 text-sm text-slate-200 uppercase font-mono focus:outline-none focus:border-purple-500 transition"
                />
              </div>

              {/* Submit Button */}
              {errMsg && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-start space-x-2 text-xs text-rose-400">
                  <AlertCircle size={16} className="mt-0.5 shrink-0" />
                  <span>{errMsg}</span>
                </div>
              )}

              {isSuccess && (
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-start space-x-2 text-xs text-emerald-400">
                  <CheckCircle size={16} className="mt-0.5 shrink-0" />
                  <span>{t.paySuccessSubmitted}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold rounded-xl py-3 text-sm transition-all shadow-md shadow-purple-900/40 flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
              >
                <span>{loading ? "Verifying..." : t.payFormSubmitBtn}</span>
                {!loading && <ArrowRight size={16} />}
              </button>

            </form>
          </div>

        </div>

        {/* Right Column: Simulated Bank SVG QR standard code */}
        <div className="space-y-6">
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 text-center flex flex-col items-center justify-center relative overflow-hidden">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 font-display mb-4 w-full text-left">
              {t.payScanQr}
            </h3>

            {/* Decorative Vector Logo Background */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-purple-500/5 rounded-full blur-3xl pointer-events-none"></div>

            {/* The KHQR Graphic Design Container */}
            <div className="relative p-5 w-72 bg-white rounded-3xl text-slate-950 flex flex-col items-center shadow-2xl border-4 border-purple-500/30">
              
              {/* KHQR Header Banner */}
              <div className="w-full flex items-center justify-between px-2 mb-3">
                <span className="text-[10px] font-black tracking-widest text-[#E31E24]">KHQR</span>
                <span className="text-[8px] font-bold text-slate-400 uppercase">Cambodia National QR</span>
              </div>

              {/* Dynamic QR SVG Generator with real QR image */}
              <div className="w-56 h-56 relative bg-white flex items-center justify-center p-2 rounded-xl border border-slate-200">
                <img 
                  referrerPolicy="no-referrer"
                  src={qrUrl}
                  alt="KHQR Payment QR Code" 
                  className="w-full h-full object-contain"
                />

                {/* Floating Central Badge customized based on bank */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 p-1 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-center font-bold text-[9px] select-none text-white shadow">
                  {selectedBank === "aba" && <span className="text-teal-400 font-extrabold tracking-tight px-1">ABA</span>}
                  {selectedBank === "acleda" && <span className="text-amber-400 font-extrabold tracking-tight px-1">ACL</span>}
                  {selectedBank === "wing" && <span className="text-lime-400 font-extrabold tracking-tight px-1">WNG</span>}
                </div>
              </div>

              {/* Dynamic QR Payment Meta details */}
              <div className="w-full mt-3 text-center border-t border-slate-100 pt-2 px-2">
                <div className="text-[10px] font-bold text-slate-400 lowercase uppercase">Recipient Merchant</div>
                <div className="text-xs font-black tracking-tight text-slate-800 uppercase mt-0.5 max-w-full truncate">
                  {bankConfig[selectedBank].accountName}
                </div>
                
                <div className="mt-1 pb-1 flex justify-center items-center space-x-1 bg-slate-50/50 rounded-lg p-1">
                  <span className="text-[10px] font-semibold text-slate-400">{currentLang === "en" ? "Ref:" : "លេខយោង:"}</span>
                  <span className="text-[10px] font-bold font-mono text-purple-700">KBOOST-{userToken.substring(4, 9).toUpperCase()}</span>
                </div>

                <div className="mt-2 text-center text-[10px] font-black text-rose-600 tracking-wider">
                  {currentLang === "en" ? "AMOUNT:" : "ចំនួនទឹកប្រាក់:"} ${parseFloat(depositAmount || "0").toFixed(2)} USD
                </div>
              </div>
            </div>

            {/* Instruction Bullet text */}
            <div className="w-full mt-5 text-left border-t border-slate-800/80 pt-4 space-y-3">
              <div id="bank-credentials-box" className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-850 flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-slate-500 uppercase font-semibold tracking-wider">Bank Gateway Account</div>
                  <div className="text-xs font-bold text-slate-300 mt-1 flex items-center space-x-1.5">
                    <span className="font-mono text-white text-sm">{bankConfig[selectedBank].accountNumber}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => copyToClipboard(bankConfig[selectedBank].accountNumber, "accNo")}
                  className="p-2 bg-slate-900 border border-slate-800 hover:border-slate-750 text-slate-400 hover:text-white rounded-lg transition shrink-0 cursor-pointer"
                >
                  {copiedId === "accNo" ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                </button>
              </div>

              {selectedBank === "acleda" ? (
                <div className="space-y-3 mt-3 text-xs leading-relaxed text-slate-300">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-amber-500 mb-1 font-sans">
                    {currentLang === "en" ? "ACLEDA MOBILE TRANSFER STEPS:" : "ជំហានប្រតិបត្តិការធនាគារ អេស៊ីលីដា ម៉ូបាល៖"}
                  </div>
                  {currentLang === "en" ? (
                    <ul className="space-y-2 list-none pl-0">
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 shrink-0 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold font-mono">1</span>
                        <span>Open the <strong className="text-white">ACLEDA Mobile</strong> app and tap the <strong className="text-amber-400 font-sans">QR Scan</strong> or <strong className="text-amber-400 font-sans">KHQR</strong> button.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 shrink-0 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold font-mono">2</span>
                        <span>Scan the dynamic QR code displayed above, which automatically prepopulates the deposit amount of <strong className="text-white font-mono">${parseFloat(depositAmount || "10").toFixed(2)} USD</strong>.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 shrink-0 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold font-mono">3</span>
                        <span>Verify that the recipient matches:
                          <div className="p-2 mt-1 bg-slate-950/60 rounded-lg border border-slate-900 leading-tight">
                            <div className="text-[9px] text-slate-500 uppercase font-sans">Recipient details</div>
                            <div className="text-[11px] font-bold text-white uppercase mt-1">{bankConfig.acleda.accountName}</div>
                            <div className="text-[11px] font-mono text-amber-400 mt-0.5">{bankConfig.acleda.accountNumber}</div>
                          </div>
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 shrink-0 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold font-mono">4</span>
                        <span>Ensure the transaction Memo/Remarks contains your unique reference code: <strong className="text-purple-400 font-mono">KBOOST-{userToken.substring(4, 9).toUpperCase()}</strong> to allow automatic matching.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 shrink-0 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold font-mono">5</span>
                        <span>Confirm and authorize the transfer. Then, copy the resulting <strong className="text-white">Transaction Reference Number (Ref No)</strong> and paste it into the submission form.</span>
                      </li>
                    </ul>
                  ) : (
                    <ul className="space-y-2 list-none pl-0">
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 shrink-0 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold font-mono">1</span>
                        <span>សូមបើកកម្មវិធីទូរស័ព្ទចូលគណនី <strong className="text-white">អេស៊ីលីដាម៉ូបាល (ACLEDA Mobile)</strong> រួចជ្រើសរើសយកប៊ូតុង <strong className="text-amber-400 font-sans">ស្កេនទូទាត់ QR / KHQR</strong>។</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 shrink-0 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold font-mono">2</span>
                        <span>ស្កេនកូដ QR ឌីណាមិកខាងលើ ដែលបានបញ្ចូលចំនួនទឹកប្រាក់រួចជាស្រេចគឺចំនួន <strong className="text-white font-mono">${parseFloat(depositAmount || "10").toFixed(2)} ដុល្លារ</strong>។</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 shrink-0 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold font-mono">3</span>
                        <span>ផ្ទៀងផ្ទាត់ព័ត៌មានអ្នកទទួល៖
                          <div className="p-2 mt-1 bg-slate-950/60 rounded-lg border border-slate-900 leading-tight">
                            <div className="text-[9px] text-slate-500 uppercase">ព័ត៌មានគណនីទទួល</div>
                            <div className="text-[11px] font-bold text-white uppercase mt-1">{bankConfig.acleda.accountName}</div>
                            <div className="text-[11px] font-mono text-amber-400 mt-0.5">{bankConfig.acleda.accountNumber}</div>
                          </div>
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 shrink-0 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold font-mono">4</span>
                        <span>សូមប្រាកដថាប្រអប់ចំណាំ (Memo) មានបញ្ចូលលេខយោងកូដសម្គាល់គណនីរបស់អ្នកគឺ៖ <strong className="text-purple-400 font-mono">KBOOST-{userToken.substring(4, 9).toUpperCase()}</strong> ដើម្បីការអនុម័តបោះទុនស្វ័យប្រវត្ត។</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-5 h-5 shrink-0 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold font-mono">5</span>
                        <span>បំពេញការផ្ទេរប្រាក់។ បន្ទាប់មកចម្លង <strong className="text-white">លេខយោងប្រតិបត្តិការ (Ref No / TXID)</strong> យកមកបំពេញក្នុងប្រអប់បញ្ជូនព័ត៌មានផ្ទៀងផ្ទាត់ខាងឆ្វេង។</span>
                      </li>
                    </ul>
                  )}
                </div>
              ) : (
                <p className="text-xs text-slate-400 leading-relaxed mt-2 pl-1.5 border-l-2 border-purple-500">
                  {selectedBank === "aba" && t.payAbaInstructions}
                  {selectedBank === "wing" && t.payWingInstructions}
                </p>
              )}
            </div>
          </div>
        </div>

      </div>

      {/* Payment Voucher History Audit Log */}
      <div id="payment-voucher-log-box" className="p-6 rounded-2xl glass-panel border border-slate-800">
        <h3 className="text-base font-bold font-display text-white mb-4">
          {currentLang === "en" ? "My Deposit Transaction Records" : "ប្រវត្តិនៃការដាក់ប្រាក់របស់ខ្ញុំ"}
        </h3>

        {myTransactions.length === 0 ? (
          <div className="p-8 rounded-xl bg-slate-950/30 border border-dashed border-slate-850 text-center">
            <p className="text-xs text-slate-500">{currentLang === "en" ? "No deposit transactions recorded yet." : "មិនទាន់មានគណនីផ្ញើប្រាក់ដើម្បីផ្ទៀងផ្ទាត់នៅឡើយទេ។"}</p>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl">
            <table className="w-full text-left text-xs border-collapse font-sans">
              <thead>
                <tr className="bg-slate-950 text-slate-400 border-b border-slate-900">
                  <th className="p-3">ID</th>
                  <th className="p-3">Bank</th>
                  <th className="p-3">Reference TXID</th>
                  <th className="p-3">Amount</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-900">
                {myTransactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-900/20 text-slate-300">
                    <td className="p-3 font-mono font-bold text-slate-500">{tx.id}</td>
                    <td className="p-3 uppercase font-bold text-slate-300">{tx.bank}</td>
                    <td className="p-3 font-mono text-purple-400">{tx.transactionId}</td>
                    <td className="p-3 font-bold text-slate-100">${tx.amount.toFixed(2)}</td>
                    <td className="p-3">
                      <span className={`px-2.5 py-1 text-[10px] font-bold rounded-lg border ${
                        tx.status === "approved"
                          ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                          : tx.status === "rejected"
                          ? "bg-rose-500/10 border-rose-500/20 text-rose-400"
                          : "bg-amber-500/10 border-amber-500/20 text-amber-400"
                      }`}>
                        {tx.status === "approved" && t.statusApproved}
                        {tx.status === "rejected" && t.statusRejected}
                        {tx.status === "pending" && t.statusPending}
                      </span>
                    </td>
                    <td className="p-3 text-slate-500">{new Date(tx.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
