import React, { useState } from "react";
import { motion } from "motion/react";
import { KhmerSMMTranslations } from "../types";
import { Terminal, Copy, Check, Code, RefreshCw } from "lucide-react";

interface APIDocsViewProps {
  currentLang: "en" | "km";
}

export default function APIDocsView({ currentLang }: APIDocsViewProps) {
  const t = KhmerSMMTranslations[currentLang];
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [apiKey, setApiKey] = useState("kboost_sec_live_9a4bf893e25b4");

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const currentHost = window.location.origin;

  const endpoints = [
    {
      method: "GET",
      path: "/api/services",
      desc: currentLang === "en" ? "Fetch list of all active SMM promotional and boost services." : "ទាញយកបញ្ជីសេវាកម្មជំរុញ និងលក់ SMM សកម្មទាំងអស់។",
      params: [
        { name: "category", type: "string (optional)", required: "No", desc: "facebook, tiktok, telegram, youtube" }
      ],
      response: `[
  {
    "id": "fb-likes-01",
    "category": "facebook",
    "nameEn": "Facebook Page Likes [Fast Speed]",
    "rateEn": 1.45,
    "minQuantity": 100,
    "maxQuantity": 50000,
    "platform": "Facebook"
  }
]`
    },
    {
      method: "POST",
      path: "/api/orders",
      desc: currentLang === "en" ? "Launch a new automated SMM promotional boost order." : "បញ្ជាទិញការជំរុញសេវាកម្ម SMM ស្វ័យប្រវត្តថ្មី។",
      headers: [
        { name: "Authorization", val: "Bearer <your_token>" }
      ],
      params: [
        { name: "serviceId", type: "string", required: "Yes", desc: "Unique service identifier (e.g. fb-likes-01)" },
        { name: "link", type: "string", required: "Yes", desc: "Profile URL or video link to boost" },
        { name: "quantity", type: "numeric", required: "Yes", desc: "Target booster quantity to add" }
      ],
      response: `{
  "message": "Order launched successfully! Watch the stats rise in real-time.",
  "order": {
    "id": "ORD-HZ72B",
    "serviceId": "fb-likes-01",
    "platform": "Facebook",
    "link": "https://facebook.com/myprofile/posts/102",
    "quantity": 1000,
    "charge": 1.45,
    "status": "processing",
    "createdAt": "2026-05-21T11:04:20Z"
  },
  "newBalance": 648.55
}`
    },
    {
      method: "POST",
      path: "/api/auth/login",
      desc: currentLang === "en" ? "Retrieve session token for programmatic authentication." : "ទាញយកលេខកូដសម្ងាត់សម្រាប់ការចូលគណនីស្វ័យប្រវត្ត។",
      params: [
        { name: "email", type: "string", required: "Yes", desc: "Your login register email" },
        { name: "password", type: "string", required: "Yes", desc: "Secure password string" }
      ],
      response: `{
  "message": "Sign in successful.",
  "token": "tok-baf893e25b4819ad249b",
  "user": {
    "id": "usr-3af9b",
    "email": "user@domain.com",
    "username": "AffiliateMaster",
    "balance": 240.50,
    "role": "user"
  }
}`
    }
  ];

  return (
    <div id="api-docs-viewport" className="space-y-8">
      {/* Title */}
      <div id="api-header-section" className="relative p-6 rounded-2xl glass-panel overflow-hidden">
        <div className="absolute top-0 right-0 p-8 h-80 w-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative flex items-center space-x-3">
          <div className="p-3 bg-purple-500/15 rounded-xl text-purple-400">
            <Terminal size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold font-display tracking-tight text-white">{t.apiTitle}</h1>
            <p className="text-sm text-slate-400 mt-1">{t.apiSub}</p>
          </div>
        </div>
      </div>

      {/* Developer API Key Generation */}
      <div id="developer-auth-container" className="p-6 rounded-2xl glass-panel border border-slate-800">
        <h2 className="text-lg font-bold font-display text-white flex items-center space-x-2">
          <Code size={18} className="text-purple-400" />
          <span>{currentLang === "en" ? "Programmatic API Credentials" : "លេខកូដសំងាត់ API វិស្វកម្ម"}</span>
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          {currentLang === "en" 
            ? "Your secure bearer token for placing orders and querying active database catalog states directly." 
            : "លេខកូដសន្តិសុខទ្វារប្រព័ន្ធរបស់អ្នកសម្រាប់បញ្ជាទិញ និងទាញយកទិន្នន័យកាតាឡុកសកម្មភ្លាមៗ។"}
        </p>
        
        <div className="mt-4 flex flex-col md:flex-row gap-3">
          <div className="flex-1 min-w-0 flex items-center bg-slate-950 rounded-xl px-4 py-3 border border-slate-850 font-mono text-sm text-purple-400 overflow-x-auto">
            <span className="select-all">{apiKey}</span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => copyToClipboard(apiKey, "apikey")}
              className="px-4 py-3 bg-slate-900 border border-slate-800 text-slate-300 rounded-xl hover:text-white hover:bg-slate-850 transition duration-200 flex items-center space-x-1.5 cursor-pointer text-xs"
            >
              {copiedText === "apikey" ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
              <span>{copiedText === "apikey" ? (currentLang === "en" ? "Copied" : "បានចម្លង") : (currentLang === "en" ? "Copy" : "ចម្លង")}</span>
            </button>
            <button
              onClick={() => setApiKey("kboost_sec_live_" + Math.random().toString(36).substring(2, 15))}
              className="p-3 bg-slate-900 border border-slate-800 text-slate-300 rounded-xl hover:text-white hover:bg-slate-850 transition duration-200 cursor-pointer"
              title="Regenerate credentials"
            >
              <RefreshCw size={14} />
            </button>
          </div>
        </div>
      </div>

      {/* API Endpoints */}
      <div id="api-endpoints-listing" className="space-y-6">
        <h3 className="text-xl font-bold font-display text-slate-100 flex items-center space-x-2">
          <span>{t.apiEndpoints}</span>
          <span className="text-xs font-semibold px-2 py-0.5 bg-slate-900 border border-slate-800 text-purple-400 rounded-full">v1.2.0</span>
        </h3>

        {endpoints.map((ep, id) => {
          const endpointId = `ep-${id}`;
          return (
            <motion.div
              id={`endpoint-card-${id}`}
              key={id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: id * 0.1 }}
              className="rounded-2xl glass-panel overflow-hidden border border-slate-850 glow-border"
            >
              {/* Endpoint signature */}
              <div className="flex flex-wrap items-center justify-between gap-4 p-5 bg-slate-950/45 border-b border-slate-900">
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 text-xs font-black tracking-wider rounded-md ${
                    ep.method === "GET" 
                      ? "bg-green-500/10 border border-green-500/20 text-green-400" 
                      : "bg-purple-500/10 border border-purple-500/20 text-purple-400"
                  }`}>
                    {ep.method}
                  </span>
                  <code className="text-sm font-semibold font-mono text-slate-100 break-all">
                    {currentHost}{ep.path}
                  </code>
                </div>
                <button
                  onClick={() => copyToClipboard(`${currentHost}${ep.path}`, endpointId)}
                  className="p-2 bg-slate-900 border border-slate-850 hover:border-slate-800 hover:text-white text-slate-400 rounded-lg transition cursor-pointer"
                  title="Copy Endpoint Link"
                >
                  {copiedText === endpointId ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                </button>
              </div>

              {/* Endpoint Context Body */}
              <div className="p-5 space-y-4">
                <p className="text-xs text-slate-300 leading-relaxed font-sans">{ep.desc}</p>

                {/* Headers */}
                {ep.headers && (
                  <div>
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Request Headers</h4>
                    <div className="bg-slate-950/80 rounded-xl p-3 border border-slate-900 space-y-1.5 font-mono text-xs">
                      {ep.headers.map((h, hIdx) => (
                        <div key={hIdx} className="flex justify-between">
                          <span className="text-slate-400 font-semibold">{h.name}:</span>
                          <span className="text-purple-350">{h.val}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Parameters Table */}
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.apiParamTable}</h4>
                  <div className="overflow-x-auto rounded-xl border border-slate-900">
                    <table className="w-full text-left border-collapse font-sans text-xs">
                      <thead>
                        <tr className="bg-slate-950 text-slate-400 border-b border-slate-900">
                          <th className="p-3 font-semibold">Parameter</th>
                          <th className="p-3 font-semibold">Type</th>
                          <th className="p-3 font-semibold">Required</th>
                          <th className="p-3 font-semibold">Description</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-900">
                        {ep.params.map((p, pIdx) => (
                          <tr key={pIdx} className="hover:bg-slate-900/30 text-slate-300">
                            <td className="p-3 font-mono font-bold text-purple-400">{p.name}</td>
                            <td className="p-3 font-mono text-slate-400">{p.type}</td>
                            <td className="p-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                p.required === "Yes" 
                                  ? "bg-rose-500/10 text-rose-450 border border-rose-500/20" 
                                  : "bg-slate-800 text-slate-450"
                              }`}>
                                {p.required}
                              </span>
                            </td>
                            <td className="p-3 text-slate-400">{p.desc}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Output Sample */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">{t.apiResponseSample}</h4>
                    <button
                      onClick={() => copyToClipboard(ep.response, `${endpointId}-res`)}
                      className="text-[10px] font-bold text-purple-400 hover:text-purple-350 flex items-center space-x-1 cursor-pointer"
                    >
                      {copiedText === `${endpointId}-res` ? <Check size={10} /> : <Copy size={10} />}
                      <span>{copiedText === `${endpointId}-res` ? (currentLang === "en" ? "Copied" : "បានចម្លង") : (currentLang === "en" ? "Copy JSON" : "ចម្លង JSON")}</span>
                    </button>
                  </div>
                  <pre className="bg-slate-950 p-4 rounded-xl border border-slate-900 font-mono text-xs text-green-400 overflow-x-auto max-h-60 leading-relaxed">
                    <code>{ep.response}</code>
                  </pre>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
