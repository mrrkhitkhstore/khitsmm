import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { KhmerSMMTranslations, SMMOrder } from "../types";
import { ClipboardList, Search, Eye, Filter, RefreshCw } from "lucide-react";

interface MyOrdersViewProps {
  currentLang: "en" | "km";
  userToken: string;
}

export default function MyOrdersView({ currentLang, userToken }: MyOrdersViewProps) {
  const t = KhmerSMMTranslations[currentLang];
  const [orders, setOrders] = useState<SMMOrder[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [activeFilter, setActiveFilter] = useState<"all" | "pending" | "processing" | "completed" | "canceled">("all");

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/orders/my", {
        headers: { Authorization: `Bearer ${userToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setOrders(data);
      }
    } catch (err) {
      console.error("Error retrieving orders history", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, [userToken]);

  // Apply search query and category filters
  const filteredOrders = orders.filter((o) => {
    const matchesSearch = o.id.toLowerCase().includes(search.toLowerCase()) ||
                          o.serviceName.toLowerCase().includes(search.toLowerCase()) ||
                          o.link.toLowerCase().includes(search.toLowerCase());
    
    const matchesCategory = activeFilter === "all" || o.status === activeFilter;

    return matchesSearch && matchesCategory;
  });

  return (
    <div id="orders-page-viewport" className="space-y-6">
      
      {/* Page Header */}
      <div id="orders-header-card" className="p-6 rounded-2xl glass-panel relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 bg-purple-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-purple-500/15 rounded-xl text-purple-400">
              <ClipboardList size={28} />
            </div>
            <div>
              <h1 className="text-2xl font-bold font-display tracking-tight text-white">{t.navOrders}</h1>
              <p className="text-sm text-slate-400 mt-1">
                {currentLang === "en" ? "Track progress, delivery counts, and order transaction statuses." : "ត្រួតពិនិត្យដំណើរការ បរិមាណដឹកជញ្ជូន និងស្ថានភាពបញ្ជាទិញ។"}
              </p>
            </div>
          </div>
          <button
            onClick={fetchOrders}
            disabled={loading}
            className="self-start md:self-center px-4 py-2.5 bg-slate-900 border border-slate-800 text-xs font-semibold text-slate-300 rounded-xl hover:text-white hover:bg-slate-850 active:scale-95 transition cursor-pointer flex items-center space-x-2"
          >
            <RefreshCw size={14} className={loading ? "animate-spin text-purple-400" : ""} />
            <span>{currentLang === "en" ? "Refresh Pipeline" : "ធ្វើបច្ចុប្បន្នភាពឡើងវិញ"}</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div id="orders-toolbar" className="flex flex-col md:flex-row gap-4 items-center justify-between bg-slate-950 p-4 rounded-xl border border-slate-900">
        
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={currentLang === "en" ? "Search order references, links..." : "ស្វែងរកលេខទិញ, តំណលីង..."}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-purple-500 transition"
          />
        </div>

        {/* Filter Tab List */}
        <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
          {["all", "pending", "processing", "completed", "canceled"].map((fit) => (
            <button
              key={fit}
              onClick={() => setActiveFilter(fit as any)}
              className={`px-3 py-1.5 text-[10px] uppercase font-bold rounded-lg border transition cursor-pointer ${
                activeFilter === fit
                  ? "bg-purple-600/15 border-purple-500/35 text-purple-400"
                  : "bg-slate-900 border-slate-850 text-slate-400 hover:text-slate-350"
              }`}
            >
              {fit === "all" && (currentLang === "en" ? "All Boosts" : "ទាំងអស់")}
              {fit === "pending" && t.statusPending}
              {fit === "processing" && t.statusProcessing}
              {fit === "completed" && t.statusCompleted}
              {fit === "canceled" && t.statusCanceled}
            </button>
          ))}
        </div>

      </div>

      {/* History table */}
      <div id="orders-table-wrapper" className="p-6 rounded-2xl glass-panel border border-slate-850">
        {loading && orders.length === 0 ? (
          <div className="text-center py-12">
            <RefreshCw size={24} className="animate-spin text-purple-500 mx-auto mb-2" />
            <p className="text-xs text-slate-400">{currentLang === "en" ? "Loading booster lists..." : "កំពុងទាញបញ្ជី..."}</p>
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-sm text-slate-500">
              {currentLang === "en" ? "No matching orders found." : "មិនមានទិន្នន័យបញ្ជាទិញទាំងនេះទេ។"}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-slate-900">
            <table className="w-full text-left text-xs border-collapse font-sans">
              <thead>
                <tr className="bg-slate-950 text-slate-400 border-b border-smart-900">
                  <th className="p-3.5 font-bold font-display uppercase tracking-widest text-[10px]">{t.thOrderId}</th>
                  <th className="p-3.5 font-bold font-display uppercase tracking-widest text-[10px]">{t.thService}</th>
                  <th className="p-3.5 font-bold font-display uppercase tracking-widest text-[10px]">{t.thLink}</th>
                  <th className="p-3.5 font-bold font-display uppercase tracking-widest text-[10px] text-center">{t.thQuantity}</th>
                  <th className="p-3.5 font-bold font-display uppercase tracking-widest text-[10px] text-center">{t.thCharge}</th>
                  <th className="p-3.5 font-bold font-display uppercase tracking-widest text-[10px]">{t.thStatus}</th>
                  <th className="p-3.5 font-bold font-display uppercase tracking-widest text-[10px]">{t.thDate}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-900">
                {filteredOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-900/10 text-slate-300 transition duration-150">
                    <td className="p-3.5 font-mono font-black text-purple-400">{ord.id}</td>
                    <td className="p-3.5">
                      <div className="font-semibold text-slate-100">{ord.serviceName}</div>
                      <div className="text-[10px] text-slate-500 font-medium mt-0.5 uppercase tracking-wider">{ord.platform}</div>
                    </td>
                    <td className="p-3.5 max-w-xs truncate font-mono text-slate-450 hover:text-purple-400 transition">
                      <a href={ord.link} target="_blank" rel="noreferrer" className="flex items-center space-x-1 underline">
                        <span className="truncate">{ord.link}</span>
                      </a>
                    </td>
                    <td className="p-3.5 text-center font-bold font-mono text-slate-200">{ord.quantity.toLocaleString()}</td>
                    <td className="p-3.5 text-center font-bold font-mono text-emerald-400">${ord.charge.toFixed(3)}</td>
                    <td className="p-3.5">
                      <span className={`px-2.5 py-1 text-[9px] font-black tracking-wider uppercase rounded-md border ${
                        ord.status === "completed"
                          ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                          : ord.status === "processing"
                          ? "bg-blue-500/10 border-blue-500/20 text-blue-400"
                          : ord.status === "canceled"
                          ? "bg-rose-500/10 border-rose-500/20 text-rose-400"
                          : "bg-amber-500/10 border-amber-500/20 text-amber-400"
                      }`}>
                        {ord.status === "completed" && t.statusCompleted}
                        {ord.status === "processing" && t.statusProcessing}
                        {ord.status === "canceled" && t.statusCanceled}
                        {ord.status === "pending" && t.statusPending}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-500 text-[10px]">{new Date(ord.createdAt).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
