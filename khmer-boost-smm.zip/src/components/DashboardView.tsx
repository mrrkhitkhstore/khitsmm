import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { KhmerSMMTranslations, SMMService, SMMOrder } from "../types";
import { 
  PlusCircle, Target, Users, LayoutDashboard, ShoppingCart, 
  HelpCircle, Sparkles, BookOpen, Facebook, Youtube, 
  Send as IconTelegram, Video, Radio, ChevronRight, AlertTriangle, ArrowRight 
} from "lucide-react";

interface DashboardViewProps {
  currentLang: "en" | "km";
  userToken: string;
  userBalance: number;
  triggerBalanceRefresh: () => void;
  onNavigateToFunds: () => void;
}

export default function DashboardView({ 
  currentLang, 
  userToken, 
  userBalance, 
  triggerBalanceRefresh,
  onNavigateToFunds 
}: DashboardViewProps) {
  const t = KhmerSMMTranslations[currentLang];

  // Services Catalog lists from server API
  const [allServices, setAllServices] = useState<SMMService[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<"facebook" | "tiktok" | "telegram" | "youtube">("facebook");
  const [selectedServiceId, setSelectedServiceId] = useState<string>("");
  const [targetLink, setTargetLink] = useState<string>("");
  const [qty, setQty] = useState<string>("1000");
  const [recentOrders, setRecentOrders] = useState<SMMOrder[]>([]);

  // State feedback states
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errMsg, setErrMsg] = useState<string | null>(null);

  // Load available catalogs
  const fetchServices = async () => {
    try {
      const res = await fetch("/api/services");
      if (res.ok) {
        const data = await res.json();
        setAllServices(data);
      }
    } catch (err) {
      console.error("Error reading services", err);
    }
  };

  // Load user's recent orders lists
  const fetchRecentOrders = async () => {
    try {
      const res = await fetch("/api/orders/my", {
        headers: { Authorization: `Bearer ${userToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        // Slice top 5 orders to display in the dashboard overview
        setRecentOrders(data.slice(0, 5));
      }
    } catch (err) {
      console.error("Error reading user orders list", err);
    }
  };

  useEffect(() => {
    fetchServices();
    fetchRecentOrders();
  }, [userToken]);

  // Adjust selected service when category shifts
  useEffect(() => {
    if (allServices.length > 0) {
      const matched = allServices.filter(s => s.category === selectedCategory);
      if (matched.length > 0) {
        setSelectedServiceId(matched[0].id);
      } else {
        setSelectedServiceId("");
      }
    }
  }, [selectedCategory, allServices]);

  const activeService = allServices.find(s => s.id === selectedServiceId);

  // Dynamic cost calculation logic
  const quantityNum = parseInt(qty, 10);
  const costFloat = (activeService && !isNaN(quantityNum) && quantityNum > 0)
    ? parseFloat(((quantityNum / 1000) * activeService.rateEn).toFixed(4))
    : 0;

  // Submit new booster order
  const handleOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg(null);
    setErrMsg(null);

    if (!selectedServiceId) {
      setErrMsg(currentLang === "en" ? "Select an SMM service item. " : "សូមជ្រើសរើសសេវាកម្ម SMM លម្អិត។");
      return;
    }

    if (!targetLink.trim()) {
      setErrMsg(currentLang === "en" ? "Enter your boost target URL." : "សូមបញ្ចូលលីងគណនី ឬវីដេអូគោលដៅ។");
      return;
    }

    if (isNaN(quantityNum) || quantityNum <= 0) {
      setErrMsg(currentLang === "en" ? "Enter a valid booster quantity." : "សូមអនុញ្ញាតបញ្ជាក់ចំនួនតម្រូវការឱ្យបានហ្មត់ចត់។");
      return;
    }

    if (activeService) {
      if (quantityNum < activeService.minQuantity || quantityNum > activeService.maxQuantity) {
        setErrMsg(
          currentLang === "en"
            ? `Booster limit error. Must be between ${activeService.minQuantity} and ${activeService.maxQuantity}.`
            : `សេវាកម្មនេះតម្រូវចំនួនចន្លោះពី ${activeService.minQuantity.toLocaleString()} ដល់ ${activeService.maxQuantity.toLocaleString()}។`
        );
        return;
      }
    }

    if (userBalance < costFloat) {
      setErrMsg(t.dashBalanceErr);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`
        },
        body: JSON.stringify({
          serviceId: selectedServiceId,
          link: targetLink.trim(),
          quantity: quantityNum
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setErrMsg(data.error || t.dashGenericErr);
      } else {
        setSuccessMsg(t.dashOrderSuccess);
        setTargetLink("");
        triggerBalanceRefresh();
        fetchRecentOrders();
      }
    } catch (err) {
      setErrMsg("Network loss. Failed to place order. Re-try.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="dashboard-container" className="space-y-8">
      
      {/* Top Welcome Alert Banner Card */}
      <div id="dashboard-welcome-banner" className="relative p-6 md:p-8 rounded-2xl glass-panel-heavy overflow-hidden border border-purple-500/20">
        {/* Glowing backdrop elements */}
        <div className="absolute top-0 right-0 h-96 w-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -bottom-10 -left-10 h-72 w-72 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="relative flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-xs font-bold text-purple-400">
              <Sparkles size={12} />
              <span>{currentLang === "en" ? "PREMIUM PANEL ACTIVE" : "ប្រព័ន្ធកំពុងដំណើរការពេញលេញ"}</span>
            </div>
            <h1 className="text-3xl font-extrabold font-display tracking-tight text-white">{t.dashWelcome}</h1>
            <p className="text-sm text-slate-300 max-w-xl">{t.dashSlogan}</p>
          </div>

          {/* User Balance card displaying */}
          <div id="balance-widget" className="p-4 rounded-xl bg-slate-950/60 border border-slate-850 flex items-center space-x-4 shrink-0 min-w-[200px] shadow-lg">
            <div className="p-3 bg-purple-500/20 rounded-xl text-purple-400 text-center">
              <ShoppingCart size={22} />
            </div>
            <div>
              <div className="text-[10px] text-slate-500 font-extrabold tracking-wider uppercase">{t.dashCurrentBalance}</div>
              <div id="user-balance-reading" className="text-xl font-black font-mono mt-0.5 text-white glow-text text-glow">
                ${userBalance.toFixed(3)} <span className="text-xs text-purple-400 font-semibold font-sans">USD</span>
              </div>
              <button 
                onClick={onNavigateToFunds}
                className="text-[10px] text-purple-400 hover:text-purple-300 font-bold uppercase tracking-wider flex items-center space-x-0.5 mt-1 cursor-pointer transition"
              >
                <span>{currentLang === "en" ? "Top Up Funds" : "បញ្ចូលលុយបន្ថែម"}</span>
                <ChevronRight size={10} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Place SMM order Form panel */}
        <div className="lg:col-span-7 space-y-6">
          <div id="new-order-form-widget" className="p-6 rounded-2xl glass-panel border border-slate-850">
            <h2 className="text-lg font-bold font-display text-white flex items-center space-x-2.5 mb-5 border-b border-slate-900 pb-3">
              <PlusCircle className="text-purple-400" size={20} />
              <span>{t.dashNewOrder}</span>
            </h2>

            <form onSubmit={handleOrderSubmit} className="space-y-5">
              
              {/* Category Selector Tabs */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-2 uppercase tracking-wider">
                  {t.dashOrderCategory}
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: "facebook", name: "Facebook", icon: Facebook, color: "text-blue-400" },
                    { id: "tiktok", name: "TikTok", icon: Video, color: "text-rose-400" },
                    { id: "telegram", name: "Telegram", icon: IconTelegram, color: "text-sky-400" },
                    { id: "youtube", name: "YouTube", icon: Youtube, color: "text-red-500" }
                  ].map((cat) => {
                    const CatIcon = cat.icon;
                    return (
                      <button
                        type="button"
                        key={cat.id}
                        onClick={() => setSelectedCategory(cat.id as any)}
                        className={`p-3 rounded-xl border flex flex-col items-center justify-center text-center transition-all cursor-pointer ${
                          selectedCategory === cat.id
                            ? "bg-purple-600/10 border-purple-500/40 text-purple-400 shadow-md"
                            : "bg-slate-950 border-slate-900 text-slate-400 hover:text-slate-300 hover:border-slate-800"
                        }`}
                      >
                        <CatIcon size={18} className={cat.color} />
                        <span className="text-[10px] font-bold mt-1.5">{cat.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Service Selection dropdown */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                  {t.dashOrderService}
                </label>
                <select
                  id="select-smm-service"
                  value={selectedServiceId}
                  onChange={(e) => setSelectedServiceId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 transition font-sans"
                >
                  {allServices
                    .filter(s => s.category === selectedCategory)
                    .map((s) => (
                      <option key={s.id} value={s.id}>
                        {currentLang === "en" ? s.nameEn : s.nameKm} — (${s.rateEn.toFixed(2)}/1K)
                      </option>
                    ))}
                  {allServices.filter(s => s.category === selectedCategory).length === 0 && (
                    <option value="">{currentLang === "en" ? "No service in this category yet." : "មិនទាន់មានសេវាកម្មក្នុងជម្រើសនេះនៅឡើយទេ។"}</option>
                  )}
                </select>
              </div>

              {/* Active Service Description card info */}
              {activeService && (
                <div id="service-metadata-box" className="p-3.5 rounded-xl bg-purple-950/10 border border-purple-900/15 text-xs text-slate-350 space-y-1 pl-4 border-l-4 border-l-purple-500 font-sans">
                  <div className="font-bold text-white uppercase text-[9px] tracking-widest flex items-center space-x-1.5">
                    <Sparkles size={10} className="text-purple-400" />
                    <span>{currentLang === "en" ? "SERVICE PERFORMANCE SPECS" : "លក្ខណៈបច្ចេកទេសរបស់សេវាកម្ម"}</span>
                  </div>
                  <p className="text-slate-300 text-xs mt-1 leading-relaxed">
                    {currentLang === "en" ? activeService.descriptionEn : activeService.descriptionKm}
                  </p>
                  <div className="flex gap-4 pt-1 text-[10px] text-slate-400 font-mono">
                    <div>
                      {currentLang === "en" ? "Category:" : "ប្រភេទ:"}{" "}
                      <span className="text-purple-400 font-medium uppercase">{activeService.platform}</span>
                    </div>
                    <div>
                      {t.dashRatePer1000}:{" "}
                      <span className="text-emerald-400 font-bold">${activeService.rateEn.toFixed(2)} USD</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Tag Link Target input */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider flex items-center space-x-1">
                  <Target size={12} className="text-slate-500" />
                  <span>{t.dashTargetLink}</span>
                </label>
                <input
                  type="text"
                  value={targetLink}
                  onChange={(e) => setTargetLink(e.target.value)}
                  placeholder={
                    selectedCategory === "facebook" 
                      ? "https://facebook.com/username/posts/1209..."
                      : selectedCategory === "tiktok"
                      ? "https://www.tiktok.com/@creator/video/7382..."
                      : selectedCategory === "telegram"
                      ? "https://t.me/channelname"
                      : "https://youtube.com/watch?v=..."
                  }
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 transition font-mono"
                />
              </div>

              {/* Quantity input & Dynamic Total cost calculator */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
                      {t.dashQuantity}
                    </label>
                    {activeService && (
                      <span className="text-[10px] text-slate-500 font-mono font-bold">
                        {t.dashMinMax.replace("{min}", activeService.minQuantity.toLocaleString()).replace("{max}", activeService.maxQuantity.toLocaleString())}
                      </span>
                    )}
                  </div>
                  <input
                    type="number"
                    value={qty}
                    onChange={(e) => setQty(e.target.value)}
                    placeholder="1000"
                    step="50"
                    className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-3 text-xs text-slate-200 font-mono focus:outline-none focus:border-purple-500 transition"
                  />
                  <div className="mt-1.5 flex gap-1">
                    {["500", "1000", "5000", "10000"].map((v) => (
                      <button
                        type="button"
                        key={v}
                        onClick={() => setQty(v)}
                        className="px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-850 hover:text-white border border-slate-850 text-[10px] font-mono text-slate-400 cursor-pointer"
                      >
                        {parseInt(v, 10).toLocaleString()}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Total Cost Display box */}
                <div id="cost-calculator-card" className="p-4 rounded-xl bg-slate-950 border border-slate-900 flex flex-col justify-center">
                  <span className="text-[10px] text-slate-500 font-extrabold uppercase tracking-wider">{t.dashTotalCharge}</span>
                  <div id="order-cost-calculated" className="text-2xl font-black font-mono text-emerald-400 mt-1 glow-text">
                    ${costFloat.toFixed(3)} <span className="text-xs text-slate-500 font-sans font-medium">USD</span>
                  </div>
                  <div className="text-[9px] text-slate-450 mt-1 font-sans">
                    {currentLang === "en" ? "*Rates calculated instantly" : "*តម្រូវទូទាត់ភ្លាមៗគិតក្នុងកាតាឡុកសកម្ម"}
                  </div>
                </div>

              </div>

              {/* Status warning info */}
              <div className="p-3.5 rounded-xl bg-blue-950/15 border border-blue-900/20 flex items-start space-x-2.5 text-xs text-blue-300">
                <Radio size={16} className="mt-0.5 animate-pulse shrink-0 text-blue-400" />
                <span className="font-medium leading-relaxed font-sans">{t.dashInstantDelivery}</span>
              </div>

              {/* Result alerts */}
              {errMsg && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-start space-x-2 text-xs text-rose-450">
                  <AlertTriangle size={16} className="mt-0.5 shrink-0" />
                  <span>{errMsg}</span>
                </div>
              )}

              {successMsg && (
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-start space-x-2 text-xs text-emerald-400">
                  <Sparkles size={16} className="mt-0.5 shrink-0 text-emerald-400" />
                  <span>{successMsg}</span>
                </div>
              )}

              {/* Action Order Button */}
              <button
                type="submit"
                disabled={loading || allServices.filter(s => s.category === selectedCategory).length === 0}
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold rounded-xl py-4 transition-all shadow-md shadow-purple-900/40 flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
              >
                <span>{loading ? "Launching Boost Engines..." : t.dashPlaceOrderBtn}</span>
                {!loading && <ArrowRight size={16} />}
              </button>

            </form>
          </div>
        </div>

        {/* Right Column: Mini FAQ & Recent order list snapshot */}
        <div className="lg:col-span-5 space-y-6 animate-fade-in">
          
          {/* Recent Orders history snapshot for quick overview */}
          <div id="recent-launches-snap" className="p-6 rounded-2xl glass-panel border border-slate-850">
            <h3 className="text-sm font-black font-display text-white uppercase tracking-wider mb-4 flex items-center space-x-2 text-purple-400">
              <ShoppingCart size={16} />
              <span>{currentLang === "en" ? "My Recent Social Launches" : "ការបញ្ជាទិញថ្មីៗរបស់ខ្ញុំ"}</span>
            </h3>

            <div className="space-y-3">
              {recentOrders.length === 0 ? (
                <div className="p-8 text-center bg-slate-950/30 border border-dashed border-slate-850 rounded-xl">
                  <p className="text-xs text-slate-500 select-none">
                    {currentLang === "en" ? "Configure your first booster above to see live updates!" : "បង្កើតការបញ្ជាទិញដំបូងរបស់អ្នកខាងលើដើម្បីមើលព័ត៌មានលម្អិត!"}
                  </p>
                </div>
              ) : (
                recentOrders.map((ord) => (
                  <div key={ord.id} className="p-3 bg-slate-950 rounded-xl border border-slate-900 hover:border-slate-800 transition duration-150 text-xs">
                    <div className="flex justify-between items-start">
                      <div>
                        {/* Title of service */}
                        <div className="font-semibold text-slate-200 line-clamp-1">{ord.serviceName}</div>
                        
                        <div className="flex items-center space-x-2 mt-1 font-mono text-[9px] text-slate-500">
                          <span className="text-purple-400 font-bold">{ord.id}</span>
                          <span>•</span>
                          <span>{ord.quantity.toLocaleString()} Qty</span>
                          <span>•</span>
                          <span className="text-emerald-400">${ord.charge.toFixed(3)}</span>
                        </div>
                      </div>

                      {/* Status indicator badge */}
                      <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase shrink-0 ${
                        ord.status === "completed"
                          ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                          : ord.status === "processing"
                          ? "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                          : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                      }`}>
                        {ord.status === "completed" && t.statusCompleted}
                        {ord.status === "processing" && t.statusProcessing}
                        {ord.status === "pending" && t.statusPending}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Tips Section */}
          <div id="promotional-tips-card" className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950/40 border border-slate-850 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 h-36 w-36 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none"></div>
            <h3 className="text-sm font-black font-display text-white uppercase tracking-wider mb-3 flex items-center space-x-2 text-indigo-400">
              <Sparkles size={16} />
              <span>{currentLang === "en" ? "Growth Guidelines" : "គោលការណ៍ណែនាំរីកចម្រើន"}</span>
            </h3>

            <ul className="text-xs text-slate-300 space-y-2.5 pl-1.5 list-none font-sans leading-relaxed">
              <li className="flex items-start">
                <span className="text-indigo-400 font-bold mr-1.5 font-mono">1.</span>
                <span>{currentLang === "en" ? "Make sure your social page or post privacy is set to Public, not private." : "សូមប្រាកដថា ទំព័របណ្តាញសង្គម ឬវីដេអូរបស់អ្នកកំណត់ជា Public (ជាសាធារណៈ)។"}</span>
              </li>
              <li className="flex items-start">
                <span className="text-indigo-400 font-bold mr-1.5 font-mono">2.</span>
                <span>{currentLang === "en" ? "Do not place duplicate orders for the same link until the first finishes." : "កុំបញ្ជាទិញត្រួតគ្នា លើលីងដដែល ច្រើនដងក្នុងពេលតែមួយ។"}</span>
              </li>
              <li className="flex items-start">
                <span className="text-indigo-400 font-bold mr-1.5 font-mono">3.</span>
                <span>{currentLang === "en" ? "Need reseller bulk pricing? Our SMM API allows fully autonomous reseller channels." : "ត្រូវការសេវាកម្មកញ្ចប់ធំសម្រាប់លក់បន្ត? API ស្វ័យប្រវត្តរបស់យើងជួយគាំទ្រអ្នកលក់បន្ត។"}</span>
              </li>
            </ul>
          </div>

        </div>

      </div>
    </div>
  );
}
