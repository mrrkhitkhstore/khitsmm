import React, { useState, useEffect } from "react";
import { KhmerSMMTranslations, SMMOrder, SMMService, UserSession, Transaction, SupportMessage } from "../types";
import { 
  ShieldCheck, Users, ShoppingCart, Coins, Settings, Database, 
  Trash2, Plus, Edit, CornerDownRight, Check, X, ArrowLeft, RefreshCw, Send 
} from "lucide-react";

interface AdminConsoleProps {
  currentLang: "en" | "km";
  userToken: string;
}

export default function AdminConsole({ currentLang, userToken }: AdminConsoleProps) {
  const t = KhmerSMMTranslations[currentLang];

  // Active Admin Tabs: "stats" | "users" | "orders" | "payments" | "services" | "tickets"
  const [activeTab, setActiveTab] = useState<"stats" | "users" | "orders" | "payments" | "services" | "tickets">("stats");

  // Core admin rosters
  const [stats, setStats] = useState({ totalSales: 0, totalOrders: 0, totalUsers: 0, pendingTransCount: 0 });
  const [usersList, setUsersList] = useState<UserSession[]>([]);
  const [ordersList, setOrdersList] = useState<SMMOrder[]>([]);
  const [paymentsList, setPaymentsList] = useState<Transaction[]>([]);
  const [servicesList, setServicesList] = useState<SMMService[]>([]);
  const [ticketsList, setTicketsList] = useState<SupportMessage[]>([]);

  // Selection states for edits/resolutions
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editUserBalance, setEditUserBalance] = useState("");
  const [isCreatingService, setIsCreatingService] = useState(false);
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);

  // SMM service creator states
  const [srvCategory, setSrvCategory] = useState<"facebook" | "tiktok" | "telegram" | "youtube">("facebook");
  const [srvPlatform, setSrvPlatform] = useState<"Facebook" | "TikTok" | "Telegram" | "YouTube">("Facebook");
  const [srvNameEn, setSrvNameEn] = useState("");
  const [srvNameKm, setSrvNameKm] = useState("");
  const [srvRateEn, setSrvRateEn] = useState("1.50");
  const [srvMin, setSrvMin] = useState("100");
  const [srvMax, setSrvMax] = useState("10000");
  const [srvDescEn, setSrvDescEn] = useState("");
  const [srvDescKm, setSrvDescKm] = useState("");

  // Support responders
  const [ticketReplyId, setTicketReplyId] = useState<string | null>(null);
  const [ticketReplyBody, setTicketReplyBody] = useState("");

  const [loading, setLoading] = useState(false);

  // Sync state values across selected categories
  useEffect(() => {
    if (srvCategory === "facebook") setSrvPlatform("Facebook");
    if (srvCategory === "tiktok") setSrvPlatform("TikTok");
    if (srvCategory === "telegram") setSrvPlatform("Telegram");
    if (srvCategory === "youtube") setSrvPlatform("YouTube");
  }, [srvCategory]);

  // Load everything
  const fetchAllData = async () => {
    setLoading(true);
    try {
      const headers = { Authorization: `Bearer ${userToken}` };
      
      // 1. Stats
      const resStats = await fetch("/api/admin/stats", { headers });
      if (resStats.ok) setStats(await resStats.json());

      // 2. Users list
      const resUsers = await fetch("/api/admin/users", { headers });
      if (resUsers.ok) setUsersList(await resUsers.json());

      // 3. Orders list
      const resOrders = await fetch("/api/admin/orders", { headers });
      if (resOrders.ok) setOrdersList(await resOrders.json());

      // 4. Receipts payments list
      const resPayments = await fetch("/api/admin/transactions", { headers });
      if (resPayments.ok) setPaymentsList(await resPayments.json());

      // 5. Active service catalogs
      const resServices = await fetch("/api/services");
      if (resServices.ok) setServicesList(await resServices.json());

      // 6. Support Tickets list
      const resTickets = await fetch("/api/admin/tickets", { headers });
      if (resTickets.ok) setTicketsList(await resTickets.json());

    } catch (err) {
      console.error("Critical error in admin panel fetch sync", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, [userToken, activeTab]);

  // Handle Edit User Profile (edit balance / change role / Toggle admin status)
  const handleModifyUser = async (userId: string, updates: { balance?: number; role?: "user" | "admin" }) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`
        },
        body: JSON.stringify(updates)
      });
      if (res.ok) {
        setEditingUserId(null);
        fetchAllData();
      }
    } catch (err) {
      console.error("Modify user profile error", err);
    }
  };

  // Resolve pending KHQR receipts matching actions
  const handleResolvePayment = async (txId: string, action: "approve" | "reject") => {
    try {
      const res = await fetch(`/api/admin/transactions/${txId}/resolve`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`
        },
        body: JSON.stringify({ action })
      });
      if (res.ok) {
        fetchAllData();
      }
    } catch (err) {
      console.error("Resolve transaction voucher error", err);
    }
  };

  // Modify Order delivery pipeline status
  const handleModifyOrderStatus = async (orderId: string, status: "pending" | "processing" | "completed" | "canceled") => {
    try {
      const res = await fetch(`/api/admin/orders/${orderId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`
        },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        fetchAllData();
      }
    } catch (err) {
      console.error("Modify order status error", err);
    }
  };

  // Create / Edit SMM Catalog Item
  const handleSaveServiceCatalog = async (e: React.FormEvent) => {
    e.preventDefault();

    const rate = parseFloat(srvRateEn);
    const minQ = parseInt(srvMin, 10);
    const maxQ = parseInt(srvMax, 10);

    if (!srvNameEn || !srvNameKm || isNaN(rate) || isNaN(minQ) || isNaN(maxQ)) {
      alert("Missing or invalid fields occurred. Verify input properties.");
      return;
    }

    const payload = {
      category: srvCategory,
      platform: srvPlatform,
      nameEn: srvNameEn,
      nameKm: srvNameKm,
      rateEn: rate,
      minQuantity: minQ,
      maxQuantity: maxQ,
      descriptionEn: srvDescEn,
      descriptionKm: srvDescKm
    };

    try {
      const url = editingServiceId ? `/api/admin/services/${editingServiceId}` : "/api/admin/services";
      const method = editingServiceId ? "PUT" : "POST";
      
      const res = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        setIsCreatingService(false);
        setEditingServiceId(null);
        resetServiceForm();
        fetchAllData();
      }
    } catch (err) {
      console.error("Saving service item failed", err);
    }
  };

  const handleEditServiceSetup = (srv: SMMService) => {
    setEditingServiceId(srv.id);
    setSrvCategory(srv.category as any);
    setSrvPlatform(srv.platform);
    setSrvNameEn(srv.nameEn);
    setSrvNameKm(srv.nameKm);
    setSrvRateEn(srv.rateEn.toString());
    setSrvMin(srv.minQuantity.toString());
    setSrvMax(srv.maxQuantity.toString());
    setSrvDescEn(srv.descriptionEn);
    setSrvDescKm(srv.descriptionKm);
    setIsCreatingService(true);
  };

  const resetServiceForm = () => {
    setSrvNameEn("");
    setSrvNameKm("");
    setSrvRateEn("1.50");
    setSrvMin("100");
    setSrvMax("10000");
    setSrvDescEn("");
    setSrvDescKm("");
  };

  // Delete Service Catalog item
  const handleDeleteService = async (serviceId: string) => {
    if (!confirm("Are you sure you want to delete this SMM service catalog permanently?")) return;
    try {
      const res = await fetch(`/api/admin/services/${serviceId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${userToken}` }
      });
      if (res.ok) {
        fetchAllData();
      }
    } catch (err) {
      console.error("Delete service error", err);
    }
  };

  // Send reply support Ticket messages
  const handleReplyToTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketReplyId || !ticketReplyBody.trim()) return;

    try {
      const res = await fetch(`/api/admin/tickets/${ticketReplyId}/reply`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`
        },
        body: JSON.stringify({ reply: ticketReplyBody.trim() })
      });
      if (res.ok) {
        setTicketReplyId(null);
        setTicketReplyBody("");
        fetchAllData();
      }
    } catch (err) {
      console.error("Replying ticket error", err);
    }
  };

  return (
    <div id="admin-panel-main" className="space-y-8 select-none">
      
      {/* Title Header area */}
      <div id="admin-header-box" className="p-6 rounded-2xl glass-panel relative overflow-hidden border border-purple-500/25">
        <div className="absolute top-0 right-0 h-44 w-44 bg-purple-600/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-red-500/15 rounded-xl text-purple-400">
              <ShieldCheck size={28} />
            </div>
            <div>
              <h1 className="text-2xl font-bold font-display tracking-tight text-white">{t.admTitle}</h1>
              <p className="text-sm text-slate-400 mt-1">{t.admSub}</p>
            </div>
          </div>
          <button
            onClick={fetchAllData}
            disabled={loading}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-850 text-slate-350 hover:text-white rounded-xl border border-slate-800 transition text-xs flex items-center space-x-2 cursor-pointer"
          >
            <RefreshCw size={14} className={loading ? "animate-spin text-purple-400" : ""} />
            <span>Sync DB</span>
          </button>
        </div>
      </div>

      {/* Tabs list menu */}
      <div id="admin-nav-tabs" className="flex flex-wrap gap-1.5 border-b border-slate-850 pb-2">
        {[
          { id: "stats", label: "Stats Overview", icon: Database },
          { id: "users", label: t.admUsersTab, icon: Users },
          { id: "orders", label: t.admOrdersTab, icon: ShoppingCart },
          { id: "payments", label: t.admTransTab, icon: Coins },
          { id: "services", label: t.admServicesTab, icon: Settings },
          { id: "tickets", label: "Support Tickets", icon: Send }
        ].map((tab) => {
          const TabIcon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                setIsCreatingService(false);
                setEditingServiceId(null);
                setEditingUserId(null);
                setTicketReplyId(null);
              }}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold font-display cursor-pointer transition flex items-center space-x-2 ${
                activeTab === tab.id
                  ? "bg-purple-600/15 text-purple-400 border border-purple-500/40"
                  : "bg-slate-950/40 hover:bg-slate-900 text-slate-400 hover:text-white"
              }`}
            >
              <TabIcon size={14} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ---- CONTENTS SWAP ---- */}

      {/* 1. STATS VIEW */}
      {activeTab === "stats" && (
        <div id="admin-stats-grids" className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-900">
              <div className="text-[10px] text-slate-500 font-extrabold uppercase tracking-wider">{t.admStatsUsers}</div>
              <div className="text-3xl font-black font-mono text-white mt-2 font-display">{stats.totalUsers}</div>
              <div className="text-[10px] text-purple-400 mt-1 font-sans">Active Clients base</div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-900">
              <div className="text-[10px] text-slate-500 font-extrabold uppercase tracking-wider">{t.admStatsOrders}</div>
              <div className="text-3xl font-black font-mono text-blue-400 mt-2 font-display">{stats.totalOrders}</div>
              <div className="text-[10px] text-blue-500 mt-1 font-sans">Booster Launches handled</div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-900">
              <div className="text-[10px] text-slate-500 font-extrabold uppercase tracking-wider">{t.admStatsVolume}</div>
              <div className="text-3xl font-black font-mono text-emerald-400 mt-2 font-display">${stats.totalSales.toFixed(2)}</div>
              <div className="text-[10px] text-emerald-500 mt-1 font-sans">Total processed sales USD</div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-900">
              <div className="text-[10px] text-slate-500 font-extrabold uppercase tracking-wider">{t.admStatsPendTrans}</div>
              <div className={`text-3xl font-black font-mono mt-2 font-display ${stats.pendingTransCount > 0 ? "text-amber-400 animate-pulse" : "text-slate-400"}`}>
                {stats.pendingTransCount}
              </div>
              <div className="text-[10px] text-amber-500 mt-1 font-sans">Transfers awaiting approval</div>
            </div>

          </div>

          {/* Quick instructions */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-purple-950/20 to-indigo-950/20 border border-purple-900/10 pl-6 border-l-4 border-l-purple-500 text-xs text-slate-350 leading-relaxed font-sans">
            <h4 className="text-sm font-bold text-slate-100 flex items-center space-x-1">
              <span>Admin Dashboard Commands Guidelines</span>
            </h4>
            <p className="mt-1.5 max-w-3xl">
              You possess complete oversight access over KHQR receipt verifications and user states. To test depositing, register a secondary test user, navigate to their Dashboard, submit a mock fund transaction in the Add Funds panel, and return to this Administrative center under <strong>&quot;KHQR Verifications&quot;</strong> to click Approve and instantly credit their balance.
            </p>
          </div>
        </div>
      )}

      {/* 2. USERS MANAGEMENT */}
      {activeTab === "users" && (
        <div id="admin-tab-users" className="p-6 rounded-2xl glass-panel border border-slate-850">
          <h3 className="text-base font-bold text-white mb-4">{t.admUsersTab}</h3>

          <div className="overflow-x-auto rounded-xl border border-slate-900">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950 text-slate-400 border-b border-slate-900">
                  <th className="p-3">User ID</th>
                  <th className="p-3">{t.admUserEmail}</th>
                  <th className="p-3">{t.admUserUsername}</th>
                  <th className="p-3">{t.admUserRole}</th>
                  <th className="p-3">{t.admUserBalance}</th>
                  <th className="p-3 text-right">{t.admAction}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-900 text-slate-350">
                {usersList.map((usr) => (
                  <tr key={usr.id} className="hover:bg-slate-900/20">
                    <td className="p-3 font-mono text-slate-500">{usr.id}</td>
                    <td className="p-3 font-semibold text-slate-200">{usr.email}</td>
                    <td className="p-3 font-mono">{usr.username}</td>
                    <td className="p-3 text-slate-300 uppercase font-extrabold text-[10px]">
                      <span className={`px-2 py-0.5 rounded ${usr.role === "admin" ? "bg-red-500/10 text-rose-400 border border-red-500/10" : "bg-slate-900 text-slate-400"}`}>
                        {usr.role}
                      </span>
                    </td>
                    <td className="p-3 font-mono font-bold text-white">
                      {editingUserId === usr.id ? (
                        <input
                          type="number"
                          value={editUserBalance}
                          onChange={(e) => setEditUserBalance(e.target.value)}
                          className="w-24 bg-slate-900 text-xs px-2 py-1 rounded text-white border border-slate-800"
                        />
                      ) : (
                        <span>${usr.balance.toFixed(3)}</span>
                      )}
                    </td>
                    <td className="p-3 text-right space-x-1">
                      {editingUserId === usr.id ? (
                        <>
                          <button
                            onClick={() => handleModifyUser(usr.id, { balance: parseFloat(editUserBalance) })}
                            className="p-1 px-2.5 bg-green-600 hover:bg-green-500 text-white font-bold rounded cursor-pointer"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingUserId(null)}
                            className="p-1 px-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded cursor-pointer"
                          >
                            Cancel
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            onClick={() => {
                              setEditingUserId(usr.id);
                              setEditUserBalance(usr.balance.toString());
                            }}
                            className="p-1.5 bg-slate-900 text-slate-300 border border-slate-850 hover:text-white rounded transition cursor-pointer text-[10px] font-bold"
                          >
                            Edit Balance
                          </button>
                          {usr.role === "user" ? (
                            <button
                              onClick={() => handleModifyUser(usr.id, { role: "admin" })}
                              className="p-1.5 bg-red-950/30 text-rose-400 border border-red-900/10 hover:bg-red-950/50 rounded transition cursor-pointer text-[10px] font-bold"
                            >
                              Make Admin
                            </button>
                          ) : (
                            usr.id !== "sys-admin-kboost" && (
                              <button
                                onClick={() => handleModifyUser(usr.id, { role: "user" })}
                                className="p-1.5 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white rounded transition cursor-pointer text-[10px] font-bold"
                              >
                                Demote
                              </button>
                            )
                          )}
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. SMM ORDERS ROUTING */}
      {activeTab === "orders" && (
        <div id="admin-tab-orders" className="p-6 rounded-2xl glass-panel border border-slate-850">
          <h3 className="text-base font-bold text-white mb-4">All Boosters Launched</h3>

          <div className="overflow-x-auto rounded-xl border border-slate-900">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950 text-slate-400 border-b border-smart-900">
                  <th className="p-3">Order ID</th>
                  <th className="p-3">User Email</th>
                  <th className="p-3">SMM Service / Category</th>
                  <th className="p-3">Target Profile Link</th>
                  <th className="p-3 text-center">Amount</th>
                  <th className="p-3 text-center">Cost</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Routing</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-900 text-slate-350">
                {ordersList.map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-900/20 text-slate-300">
                    <td className="p-3 font-mono font-black text-purple-400">{ord.id}</td>
                    <td className="p-3 font-semibold text-slate-400">{ord.userEmail}</td>
                    <td className="p-3">
                      <div className="text-slate-100 font-semibold">{ord.serviceName}</div>
                      <div className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">{ord.platform}</div>
                    </td>
                    <td className="p-3 max-w-[150px] truncate font-mono text-xs hover:text-purple-400">
                      <a href={ord.link} target="_blank" rel="noreferrer" className="underline">{ord.link}</a>
                    </td>
                    <td className="p-3 text-center font-mono font-bold text-slate-200">{ord.quantity.toLocaleString()}</td>
                    <td className="p-3 text-center font-mono font-bold text-emerald-400">${ord.charge.toFixed(3)}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider border ${
                        ord.status === "completed"
                          ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                          : ord.status === "processing"
                          ? "bg-blue-500/10 border-blue-500/20 text-blue-400"
                          : ord.status === "canceled"
                          ? "bg-rose-500/10 border-rose-500/20 text-rose-400"
                          : "bg-amber-500/10 border-amber-500/25 text-amber-400"
                      }`}>
                        {ord.status}
                      </span>
                    </td>
                    <td className="p-3 text-right space-x-1">
                      {["pending", "processing", "completed", "canceled"].map((st) => (
                        <button
                          key={st}
                          onClick={() => handleModifyOrderStatus(ord.id, st as any)}
                          className={`p-1 px-1.5 transition text-[9px] font-black uppercase rounded cursor-pointer ${
                            ord.status === st
                              ? "bg-slate-800 text-white"
                              : "bg-slate-950 text-slate-500 border border-slate-900 hover:text-slate-350"
                          }`}
                        >
                          {st.substring(0, 4)}
                        </button>
                      ))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. KHQR VERIFICATIONS */}
      {activeTab === "payments" && (
        <div id="admin-tab-payments" className="p-6 rounded-2xl glass-panel border border-slate-850">
          <h3 className="text-base font-bold text-white mb-4">{t.admTransTab}</h3>

          <div className="overflow-x-auto rounded-xl border border-slate-900 font-sans">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950 text-slate-400 border-b border-smart-900">
                  <th className="p-3">ID</th>
                  <th className="p-3">User Email</th>
                  <th className="p-3">Bank gateway</th>
                  <th className="p-3">Reference String</th>
                  <th className="p-3">Amount Sent</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Created</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-900 text-slate-350">
                {paymentsList.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-900/20">
                    <td className="p-3 font-mono font-bold text-slate-500">{tx.id}</td>
                    <td className="p-3 font-medium text-slate-400">{tx.userEmail}</td>
                    <td className="p-3 uppercase font-bold text-slate-300">{tx.bank}</td>
                    <td className="p-3 font-mono text-purple-400 font-black">{tx.transactionId}</td>
                    <td className="p-3 font-mono font-bold text-white">${tx.amount.toFixed(2)}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                        tx.status === "approved" 
                          ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                          : tx.status === "rejected"
                          ? "bg-rose-500/10 text-rose-450 border border-rose-500/20"
                          : "bg-amber-500/10 text-amber-400 border border-amber-500/25 animate-pulse"
                      }`}>
                        {tx.status}
                      </span>
                    </td>
                    <td className="p-3 text-slate-500 font-mono text-[10px]">{new Date(tx.createdAt).toLocaleDateString()}</td>
                    <td className="p-3 text-right">
                      {tx.status === "pending" ? (
                        <div className="inline-flex space-x-1.5">
                          <button
                            onClick={() => handleResolvePayment(tx.id, "approve")}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white rounded p-1.5 cursor-pointer"
                            title="Approve and Credit Wallet"
                          >
                            <Check size={14} />
                          </button>
                          <button
                            onClick={() => handleResolvePayment(tx.id, "reject")}
                            className="bg-rose-600 hover:bg-rose-500 text-white rounded p-1.5 cursor-pointer"
                            title="Reject deposit"
                          >
                            <X size={14} />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-500 italic">Resolved</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. SERVICES CATALOGS */}
      {activeTab === "services" && (
        <div id="admin-tab-services" className="space-y-6">
          <div className="flex justify-between items-center bg-slate-950 p-4 rounded-xl border border-slate-900">
            <h3 className="text-base font-bold text-white">{t.admServicesTab}</h3>
            {!isCreatingService && (
              <button
                onClick={() => {
                  setEditingServiceId(null);
                  resetServiceForm();
                  setIsCreatingService(true);
                }}
                className="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-xl text-xs font-semibold hover:from-purple-500 hover:to-indigo-500 flex items-center space-x-1 cursor-pointer transition"
              >
                <Plus size={14} />
                <span>Add SMM Service</span>
              </button>
            )}
          </div>

          {/* Service Editor Form */}
          {isCreatingService && (
            <div className="p-6 rounded-2xl glass-panel border border-slate-800">
              <h4 className="text-sm font-bold text-slate-100 flex items-center space-x-1.5 mb-4">
                <span>{editingServiceId ? "Modify SMM Service" : "Register SMM Service Catalog"}</span>
              </h4>

              <form onSubmit={handleSaveServiceCatalog} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Category */}
                  <div>
                    <label className="block text-xs text-slate-400 mb-1 font-semibold uppercase">Category</label>
                    <select
                      value={srvCategory}
                      onChange={(e) => setSrvCategory(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none"
                    >
                      <option value="facebook">facebook</option>
                      <option value="tiktok">tiktok</option>
                      <option value="telegram">telegram</option>
                      <option value="youtube">youtube</option>
                    </select>
                  </div>

                  {/* Pricing Rate */}
                  <div>
                    <label className="block text-xs text-slate-400 mb-1 font-semibold uppercase">Rate per 1000 ($ USD)</label>
                    <input
                      type="number"
                      step="any"
                      value={srvRateEn}
                      onChange={(e) => setSrvRateEn(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1 font-semibold uppercase">Min</label>
                      <input
                        type="number"
                        value={srvMin}
                        onChange={(e) => setSrvMin(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1 font-semibold uppercase">Max</label>
                      <input
                        type="number"
                        value={srvMax}
                        onChange={(e) => setSrvMax(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1 font-semibold uppercase">Service Name (ENG)</label>
                    <input
                      type="text"
                      value={srvNameEn}
                      onChange={(e) => setSrvNameEn(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none"
                      placeholder="e.g. TikTok Premium Fast Likes"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1 font-semibold uppercase">Service Name (KHMER)</label>
                    <input
                      type="text"
                      value={srvNameKm}
                      onChange={(e) => setSrvNameKm(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none"
                      placeholder="e.g. អ្នកចូលចិត្តវីដេអូ TikTok ល្បឿនលឿន"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1 font-semibold uppercase">Description (ENG)</label>
                    <textarea
                      value={srvDescEn}
                      onChange={(e) => setSrvDescEn(e.target.value)}
                      rows={2}
                      className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1 font-semibold uppercase">Description (KHMER)</label>
                    <textarea
                      value={srvDescKm}
                      onChange={(e) => setSrvDescKm(e.target.value)}
                      rows={2}
                      className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsCreatingService(false);
                      setEditingServiceId(null);
                    }}
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-850 text-slate-350 hover:text-white rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold shadow shadow-purple-950 cursor-pointer"
                  >
                    Save SMM catalog
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Services List Table */}
          <div className="overflow-x-auto rounded-xl border border-slate-900 bg-slate-950">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950 text-slate-400 border-b border-smart-900">
                  <th className="p-3">ID</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">SMM Service Name (ENG / KHM)</th>
                  <th className="p-3 text-center">Rate / 1K</th>
                  <th className="p-3 text-center">Min / Max bounds</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-900 text-slate-300">
                {servicesList.map((srv) => (
                  <tr key={srv.id} className="hover:bg-slate-900/10">
                    <td className="p-3 font-mono text-slate-500">{srv.id}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase text-purple-400 bg-purple-500/10 border border-purple-500/15">
                        {srv.category}
                      </span>
                    </td>
                    <td className="p-3">
                      <div className="font-semibold text-slate-200">{srv.nameEn}</div>
                      <div className="text-[10px] text-slate-500 font-medium mt-0.5">{srv.nameKm}</div>
                    </td>
                    <td className="p-3 text-center font-mono font-bold text-emerald-400">${srv.rateEn.toFixed(2)}</td>
                    <td className="p-3 text-center font-mono text-slate-400">{srv.minQuantity} / {srv.maxQuantity}</td>
                    <td className="p-3 text-right space-x-1.5">
                      <button
                        onClick={() => handleEditServiceSetup(srv)}
                        className="p-1 px-2 bg-slate-900 hover:bg-slate-850 hover:text-white border border-slate-800 rounded transition cursor-pointer text-[10px]"
                      >
                        <Edit size={12} />
                      </button>
                      <button
                        onClick={() => handleDeleteService(srv.id)}
                        className="p-1 px-2 bg-rose-950/20 hover:bg-rose-950/40 text-rose-400 border border-rose-900/10 rounded transition cursor-pointer text-[10px]"
                      >
                        <Trash2 size={12} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. SUPPORT TICKETS VIEWS */}
      {activeTab === "tickets" && (
        <div id="admin-tab-tickets" className="space-y-6">
          <div className="flex justify-between items-center bg-slate-950 p-4 rounded-xl border border-slate-900">
            <h3 className="text-base font-bold text-white">Pending Client Discussions</h3>
          </div>

          <div className="space-y-4">
            {ticketsList.length === 0 ? (
              <div className="p-12 text-center bg-slate-950 rounded-xl border">
                <p className="text-xs text-slate-500">No client support tickets active.</p>
              </div>
            ) : (
              ticketsList.map((tkt) => (
                <div key={tkt.id} className="p-5 rounded-2xl bg-slate-950 border border-slate-900 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-0.5 text-[8px] font-black rounded uppercase ${tkt.status === "answered" ? "bg-green-500/10 text-green-400" : "bg-amber-500/10 text-amber-400 animate-pulse"}`}>
                          {tkt.status}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">Ticket: {tkt.id}</span>
                        <span className="text-slate-500">•</span>
                        <span className="text-[10px] text-purple-400 font-semibold uppercase font-mono">{tkt.userEmail}</span>
                      </div>
                      <h4 className="text-sm font-bold text-slate-200 mt-2">{tkt.subject}</h4>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">{new Date(tkt.createdAt).toLocaleString()}</span>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed bg-slate-900/40 p-3 rounded-lg border">
                    {tkt.message}
                  </p>

                  {/* Previous responses */}
                  {tkt.reply && (
                    <div className="p-3 pl-4 rounded-lg bg-purple-950/10 border-l-4 border-l-purple-500 border border-purple-500/10">
                      <div className="text-[9px] uppercase font-bold text-purple-400">Previous Response Answer</div>
                      <p className="text-xs text-slate-300 mt-1">{tkt.reply}</p>
                    </div>
                  )}

                  {/* Reply trigger input box */}
                  {ticketReplyId === tkt.id ? (
                    <form onSubmit={handleReplyToTicket} className="space-y-2 pt-2">
                      <div className="flex gap-2">
                        <textarea
                          rows={2}
                          value={ticketReplyBody}
                          onChange={(e) => setTicketReplyBody(e.target.value)}
                          placeholder="Draft support answer response..."
                          className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none"
                        />
                      </div>
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setTicketReplyId(null);
                            setTicketReplyBody("");
                          }}
                          className="px-3 py-1.5 bg-slate-900 text-slate-400 rounded-lg text-[10px] font-bold cursor-pointer hover:text-white"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-4 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-[10px] font-bold cursor-pointer"
                        >
                          Send reply
                        </button>
                      </div>
                    </form>
                  ) : (
                    <button
                      onClick={() => {
                        setTicketReplyId(tkt.id);
                        setTicketReplyBody(tkt.reply || "");
                      }}
                      className="px-3.5 py-1.5 bg-slate-900 border border-slate-850 hover:bg-slate-850 text-slate-300 rounded-xl text-[10px] font-bold cursor-pointer flex items-center space-x-1"
                    >
                      <span>{tkt.reply ? "Edit reply" : "Write team reply reply"}</span>
                      <CornerDownRight size={10} />
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

    </div>
  );
}
