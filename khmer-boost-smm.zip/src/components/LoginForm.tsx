import React, { useState } from "react";
import { KhmerSMMTranslations, UserSession } from "../types";
import { ShieldAlert, LogIn, UserPlus, KeyRound, ArrowLeft, Mail, User, Lock, AlertCircle, Sparkles } from "lucide-react";

interface LoginFormProps {
  currentLang: "en" | "km";
  onAuthSuccess: (session: { token: string; user: UserSession }) => void;
}

export default function LoginForm({ currentLang, onAuthSuccess }: LoginFormProps) {
  const t = KhmerSMMTranslations[currentLang];

  // Auth internal screens: "login" | "register" | "forgot"
  const [screen, setScreen] = useState<"login" | "register" | "forgot">("login");

  // Input states
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  
  // States
  const [loading, setLoading] = useState(false);
  const [errMsg, setErrMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Sign In handler
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrMsg(null);
    setSuccessMsg(null);

    if (!email || !password) {
      setErrMsg(t.authFormErrors);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), password })
      });
      const data = await res.json();
      if (!res.ok) {
        setErrMsg(data.error || "Login credentials failed.");
      } else {
        // Logged in
        onAuthSuccess({
          token: data.token,
          user: data.user
        });
      }
    } catch (err) {
      setErrMsg("Network error on authentication server. Retry.");
    } finally {
      setLoading(false);
    }
  };

  // Sign Up handler
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrMsg(null);
    setSuccessMsg(null);

    if (!email || !username || !password || !confirmPassword) {
      setErrMsg(t.authFormErrors);
      return;
    }

    if (password !== confirmPassword) {
      setErrMsg(t.authPassMismatch);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: email.trim(),
          username: username.trim(),
          password
        })
      });
      const data = await res.json();
      if (!res.ok) {
        setErrMsg(data.error || "Registration rejected.");
      } else {
        // Registered and autologged
        onAuthSuccess({
          token: data.token,
          user: data.user
        });
      }
    } catch (err) {
      setErrMsg("Registration failed due to server offline.");
    } finally {
      setLoading(false);
    }
  };

  // Reset password simulation handler
  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrMsg(null);
    setSuccessMsg(null);

    if (!email || !password) {
      setErrMsg(currentLang === "en" ? "Fill email and specify your desired new password." : "សូមបំពេញអាសយដ្ឋានអ៊ីមែល និងលេខសម្ងាត់ថ្មីរបស់អ្នក។");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: email.trim(),
          newPassword: password
        })
      });
      const data = await res.json();
      if (!res.ok) {
        setErrMsg(data.error || "Email not registered.");
      } else {
        setSuccessMsg(data.message);
        setTimeout(() => {
          setScreen("login");
          setSuccessMsg(null);
        }, 3000);
      }
    } catch (err) {
      setErrMsg("Failed to connect to resets backend.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="auth-main-wrapper" className="max-w-md w-full mx-auto my-12 relative">
      
      {/* Visual background flares */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-purple-600/15 rounded-full blur-3xl pointer-events-none"></div>

      <div id="auth-box" className="p-8 rounded-3xl glass-panel relative border border-slate-800 shadow-2xl">
        
        {/* Toggle navigation bar header */}
        <div className="text-center space-y-2 mb-6">
          <div className="inline-flex p-3 bg-purple-500/15 rounded-2xl text-purple-400 mb-2">
            {screen === "login" && <LogIn size={26} />}
            {screen === "register" && <UserPlus size={26} />}
            {screen === "forgot" && <KeyRound size={26} />}
          </div>
          
          <h2 className="text-2xl font-extrabold font-display tracking-tight text-white">
            {screen === "login" && t.authWelcomeBack}
            {screen === "register" && t.navRegister}
            {screen === "forgot" && t.authResetPassword}
          </h2>
          <p className="text-xs text-slate-400">{t.authSlogan}</p>
        </div>

        {/* State Alert Box */}
        {errMsg && (
          <div className="p-3 mb-4 bg-rose-500/10 border border-rose-500/20 text-xs text-rose-450 rounded-xl flex items-center space-x-2">
            <AlertCircle size={16} className="shrink-0 text-rose-400" />
            <span>{errMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3 mb-4 bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-400 rounded-xl flex items-center space-x-2">
            <Sparkles size={16} className="shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* 1. SIGN IN SCREEN */}
        {screen === "login" && (
          <form onSubmit={handleLogin} className="space-y-4 font-sans">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">{t.authEmail}</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@domain.com"
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 transition"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">{t.authPassword}</label>
                <button
                  type="button"
                  onClick={() => {
                    setErrMsg(null);
                    setSuccessMsg(null);
                    setScreen("forgot");
                  }}
                  className="text-xs font-semibold text-purple-400 hover:text-purple-300 cursor-pointer"
                >
                  {t.authForgotPassword}
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 transition"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold rounded-xl py-3.5 text-xs transition shadow-md shadow-purple-900/30 flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
            >
              <span>{loading ? "Authenticating..." : t.authSignInBtn}</span>
            </button>

            <div className="text-center pt-4 border-t border-slate-900/60">
              <span className="text-xs text-slate-400">
                {t.authNoAccount}{" "}
                <button
                  type="button"
                  onClick={() => {
                    setErrMsg(null);
                    setSuccessMsg(null);
                    setScreen("register");
                  }}
                  className="text-purple-400 hover:text-purple-300 font-bold ml-1 cursor-pointer"
                >
                  {t.authSignUpBtn}
                </button>
              </span>
            </div>
          </form>
        )}

        {/* 2. REGISTER SCREEN */}
        {screen === "register" && (
          <form onSubmit={handleRegister} className="space-y-4 font-sans">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">{t.authUsername}</label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. mrrboost"
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">{t.authEmail}</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="booster@domain.com"
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">{t.authPassword}</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Create secure password"
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">{t.authConfirmPassword}</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Retype password for safety"
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 transition"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold rounded-xl py-3.5 text-xs transition shadow-md shadow-purple-900/30 flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
            >
              <span>{loading ? "Registering account..." : t.authSignUpBtn}</span>
            </button>

            <div className="text-center pt-4 border-t border-slate-900/60">
              <span className="text-xs text-slate-400">
                {t.authHaveAccount}{" "}
                <button
                  type="button"
                  onClick={() => {
                    setErrMsg(null);
                    setSuccessMsg(null);
                    setScreen("login");
                  }}
                  className="text-purple-400 hover:text-purple-300 font-bold ml-1 cursor-pointer"
                >
                  {t.authSignInBtn}
                </button>
              </span>
            </div>
          </form>
        )}

        {/* 3. FORGOT PASSWORD SIMULATION */}
        {screen === "forgot" && (
          <form onSubmit={handleForgotPassword} className="space-y-4 font-sans">
            <p className="text-xs text-slate-300 leading-relaxed text-center mb-4">
              {currentLang === "en" 
                ? "Enter your email along with the new password you want to swap for. This simulation resets the backend JSON credentials instantly."
                : "សូមបញ្ចូលអាសយដ្ឋានអ៊ីមែលរបស់អ្នក រួមជាមួយលេខសម្ងាត់ថ្មីដែលអ្នកចង់បាន។ ដំណើរការនេះនឹងជំនួសគណនីក្នុងមូលដ្ឋានទិន្នន័យភ្លាមៗ។"}
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">{t.authEmail}</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="user@domain.com"
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">{currentLang === "en" ? "Desired New Password" : "លេខសម្ងាត់ថ្មីដែលចង់បាន"}</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Specify new password"
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 transition"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-purple-600 hover:bg-purple-500 text-white font-semibold rounded-xl py-3.5 text-xs transition shadow-md cursor-pointer flex items-center justify-center disabled:opacity-50"
            >
              <span>{loading ? "Swapping credentials..." : t.authResetPassword}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setErrMsg(null);
                setSuccessMsg(null);
                setScreen("login");
              }}
              className="w-full px-4 py-2 mt-2 text-xs font-semibold text-slate-400 hover:text-white transition flex items-center justify-center space-x-1 cursor-pointer"
            >
              <ArrowLeft size={14} />
              <span>{currentLang === "en" ? "Back to Sign In" : "ត្រឡប់ទៅការចូលគណនីវិញ"}</span>
            </button>
          </form>
        )}

      </div>
    </div>
  );
}
