import React, { useState, useEffect } from "react";
import { KhmerSMMTranslations, SupportMessage } from "../types";
import { MessageSquare, Calendar, HelpCircle, Send, AlertCircle, CheckCircle, RefreshCw } from "lucide-react";

interface ContactViewProps {
  currentLang: "en" | "km";
  userToken: string;
}

export default function ContactView({ currentLang, userToken }: ContactViewProps) {
  const t = KhmerSMMTranslations[currentLang];
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [tickets, setTickets] = useState<SupportMessage[]>([]);
  
  const [loading, setLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errMsg, setErrMsg] = useState<string | null>(null);

  const fetchTickets = async () => {
    try {
      const res = await fetch("/api/tickets/my", {
        headers: { Authorization: `Bearer ${userToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setTickets(data);
      }
    } catch (err) {
      console.error("Error retrieving user support tickets", err);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, [userToken]);

  const handleTicketSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrMsg(null);
    setIsSuccess(false);

    if (!subject.trim() || !message.trim()) {
      setErrMsg(currentLang === "en" ? "Fields cannot be empty." : "សូមបំពេញសេចក្តីលម្អិតទាំងអស់។");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/tickets", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`
        },
        body: JSON.stringify({
          subject: subject.trim(),
          message: message.trim()
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setErrMsg(data.error || "Failed to open support ticket.");
      } else {
        setIsSuccess(true);
        setSubject("");
        setMessage("");
        fetchTickets();
      }
    } catch (err) {
      setErrMsg("Network failure. Please refresh and try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="support-panel" className="space-y-8">
      {/* Page Header */}
      <div id="support-header" className="p-6 rounded-2xl glass-panel relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 bg-purple-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-purple-500/15 rounded-xl text-purple-400">
            <MessageSquare size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold font-display tracking-tight text-white">{t.supTitle}</h1>
            <p className="text-sm text-slate-400 mt-1">{t.supSub}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Contact Form input */}
        <div className="lg:col-span-5">
          <div className="p-6 rounded-2xl glass-panel border border-slate-800">
            <h3 className="text-base font-bold font-display text-white mb-4 flex items-center space-x-2">
              <HelpCircle size={18} className="text-purple-400" />
              <span>{currentLang === "en" ? "Submit Support Ticket" : "បើកសំបុត្រសំណូមពរថ្មី"}</span>
            </h3>

            <form onSubmit={handleTicketSubmit} className="space-y-4">
              
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                  {t.supSubject}
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder={currentLang === "en" ? "e.g. Deposit missing, TikTok views slow" : "ឧទាហរណ៍៖ ការបញ្ចូលលុយមិនចូល, យឺតល្បឿន TikTok"}
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                  {t.supMessage}
                </label>
                <textarea
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={currentLang === "en" ? "Explain details about your order ID or transaction TXID..." : "សូមរៀបរាប់ដំណើរការបញ្ហា ឬលេខយោងទិញលម្អិត..."}
                  className="w-full bg-slate-950 border border-slate-900 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-purple-500 transition"
                />
              </div>

              {errMsg && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-start space-x-2 text-xs text-rose-400">
                  <AlertCircle size={16} className="mt-0.5 shrink-0" />
                  <span>{errMsg}</span>
                </div>
              )}

              {isSuccess && (
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-start space-x-2 text-xs text-emerald-400">
                  <CheckCircle size={16} className="mt-0.5 shrink-0" />
                  <span>{t.supSuccess}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold rounded-xl py-3 text-sm transition-all shadow-md shadow-purple-900/40 flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
              >
                <span>{loading ? "Sending..." : t.supSubmitBtn}</span>
                <Send size={14} className="ml-0.5" />
              </button>

            </form>
          </div>
        </div>

        {/* Tickets and resolution history list */}
        <div className="lg:col-span-7">
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 h-full flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold font-display text-white">
                {t.supResponseTitle}
              </h3>
              <button
                onClick={fetchTickets}
                className="p-2 bg-slate-950 border border-slate-900 text-slate-400 hover:text-white rounded-lg transition"
                title="Refresh Tickets List"
              >
                <RefreshCw size={14} />
              </button>
            </div>

            {/* List */}
            <div className="flex-1 space-y-4 overflow-y-auto max-h-[420px] pr-1">
              {tickets.length === 0 ? (
                <div className="h-full flex flex-col justify-center items-center py-12 text-center">
                  <p className="text-xs text-slate-500 leading-relaxed max-w-xs">{t.supNoTickets}</p>
                </div>
              ) : (
                tickets.map((tkt) => (
                  <div key={tkt.id} className="p-4 rounded-xl bg-slate-950 border border-slate-900 space-y-3">
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        {/* Status Checkbox */}
                        <div className="flex items-center space-x-2">
                          <span className={`px-2 py-0.5 text-[8px] font-black rounded uppercase tracking-wider ${
                            tkt.status === "answered"
                              ? "bg-green-500/10 text-green-400 border border-green-500/20"
                              : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                          }`}>
                            {tkt.status === "answered" ? "Resolved" : "Active Open"}
                          </span>
                          <span className="text-[10px] font-mono text-slate-500">ID: {tkt.id}</span>
                        </div>
                        <h4 className="text-xs font-bold text-slate-200 mt-1.5">{tkt.subject}</h4>
                      </div>
                      <span className="text-[10px] text-slate-500 shrink-0 font-mono flex items-center gap-1">
                        <Calendar size={10} />
                        {new Date(tkt.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <p className="text-xs text-slate-400 font-sans break-words bg-slate-900/60 p-2.5 rounded-lg border border-slate-900">
                      {tkt.message}
                    </p>

                    {/* Replies */}
                    {tkt.reply ? (
                      <div className="p-3.5 rounded-lg bg-purple-950/20 border border-purple-900/30 pl-4 border-l-4 border-l-purple-500">
                        <div className="text-[10px] uppercase font-black tracking-widest text-purple-400 font-display">Client Support Engineer Team</div>
                        <p className="text-xs text-purple-200 font-medium mt-1 select-text leading-relaxed">
                          {tkt.reply}
                        </p>
                      </div>
                    ) : (
                      <div className="text-[10px] italic text-slate-500 select-none">
                        ⏳ {currentLang === "en" ? "Waiting for tech responder assignment..." : "កំពុងរង់ចាំការតបពីក្រុមការងារបច្ចេកទេស..."}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
