import React, { useState, useEffect } from "react";
import { KhmerSMMTranslations, SMMService } from "../types";
import { 
  Sparkles, ShieldCheck, Heart, User, Star, ChevronDown, Check, 
  ArrowRight, Facebook, Youtube, Send as IconTelegram, Video, Radio 
} from "lucide-react";

interface LandingPageProps {
  currentLang: "en" | "km";
  onNavigateToRegister: () => void;
  onNavigateToLogin: () => void;
  onNavigateToServices: () => void;
}

export default function LandingPage({ 
  currentLang, 
  onNavigateToRegister, 
  onNavigateToLogin,
  onNavigateToServices 
}: LandingPageProps) {
  const t = KhmerSMMTranslations[currentLang];

  // Services category filtering state on the landing showcase
  const [selectedCat, setSelectedCat] = useState<"facebook" | "tiktok" | "telegram" | "youtube">("facebook");
  const [faqOpenIdx, setFaqOpenIdx] = useState<number | null>(0);

  // Static services showcase to avoid missing service lists before user registers
  const sampleServices: SMMService[] = [
    {
      id: "fb-1",
      category: "facebook",
      nameEn: "Facebook Profile Likes [Normal Speed, Real Accounts]",
      nameKm: "អ្នកចូលចិត្តគណនីហ៊្វេសប៊ុក [ល្បឿនធម្មតា, គណនីពិតញែក]",
      rateEn: 1.20,
      minQuantity: 100,
      maxQuantity: 10000,
      descriptionEn: "High retention profile likes on any posts, photos, or updates.",
      descriptionKm: "ការចូលចិត្តគណនីដែលមានសុវត្ថិភាពខ្ពស់ លើរាល់ការបង្ហោះ រូបភាព ឬបច្ចុប្បន្នភាព។",
      platform: "Facebook"
    },
    {
      id: "fb-2",
      category: "facebook",
      nameEn: "Facebook Page Followers [No Refill, Instant]",
      nameKm: "អ្នកតាមដានទំព័រ Facebook [មិនមានលក្ខខណ្ឌបន្ថែម, ភ្លាមៗ]",
      rateEn: 1.45,
      minQuantity: 100,
      maxQuantity: 50000,
      descriptionEn: "Instant launch within 2 minutes. High volume capability.",
      descriptionKm: "ដំណើរការភ្លាមៗក្នុងរយៈពេល ២ នាទី។ សមត្ថភាពទទួលបរិមាណខ្ពស់។",
      platform: "Facebook"
    },
    {
      id: "tk-1",
      category: "tiktok",
      nameEn: "TikTok High Quality Views [Super Fast, Algorithm Safe]",
      nameKm: "អ្នកមើលវីដេអូ TikTok គុណភាពខ្ពស់ [លឿនរហ័ស, សុវត្ថិភាពក្បួនដោះស្រាយ]",
      rateEn: 0.15,
      minQuantity: 500,
      maxQuantity: 1000000,
      descriptionEn: "Increases discoverability on FYP. Recommended for music creators.",
      descriptionKm: "ជួយជម្រុញការរាវរកឃើញលើទំព័រ FYP។ ណែនាំសម្រាប់អ្នកបង្កើតតន្ត្រី។",
      platform: "TikTok"
    },
    {
      id: "tk-2",
      category: "tiktok",
      nameEn: "TikTok Active Profile Followers [Real Mix]",
      nameKm: "អ្នកតាមដានប្រវត្តិរូប TikTok សកម្ម [ប្រភពចម្រុះពិតប្រាកដ]",
      rateEn: 2.30,
      minQuantity: 100,
      maxQuantity: 20000,
      descriptionEn: "High retention, organic speed drip delivery to avoid bans.",
      descriptionKm: "ការរក្សាទុករយៈពេលយូរ ល្បឿនធម្មជាតិដើម្បីជៀសវាងការបិទគណនី។",
      platform: "TikTok"
    },
    {
      id: "tg-1",
      category: "telegram",
      nameEn: "Telegram Channel Members [Premium Global Names]",
      nameKm: "សមាជិកប៉ុស្តិ៍តេឡេក្រាម [គណនីឈ្មោះអន្តរជាតិលំដាប់ខ្ពស់]",
      rateEn: 0.90,
      minQuantity: 100,
      maxQuantity: 50000,
      descriptionEn: "Safe channel members matching cryptocurrency niches and shopping.",
      descriptionKm: "សមាជិកប៉ុស្តិ៍មានសុវត្ថិភាពខ្ពស់ ស័ក្តិសមជាមួយគ្រីបតូ និងការលក់ទំនិញអនឡាញ។",
      platform: "Telegram"
    },
    {
      id: "yt-1",
      category: "youtube",
      nameEn: "YouTube Monetized retention Views [Slow Safe Drip, 30s min]",
      nameKm: "អ្នកទស្សនាវីដេអូរកលុយ YouTube [ល្បឿនចែកចាយសុវត្ថិភាព, ៣០វិនាទីយ៉ាងតិច]",
      rateEn: 1.85,
      minQuantity: 200,
      maxQuantity: 100000,
      descriptionEn: "Secure monetizable traffic checking strict quality metrics.",
      descriptionKm: "លំហូរទស្សនាដែលមានសុវត្ថិភាពខ្ពស់ ឆ្លងកាត់លក្ខខណ្ឌគុណភាពតឹងរ៉ឹងរបស់ YouTube។",
      platform: "YouTube"
    }
  ];

  const filteredSample = sampleServices.filter(s => s.category === selectedCat);

  // Reviews Data
  const reviews = [
    {
      name: "Mrr Sophal",
      role: currentLang === "en" ? "Digital Influencer (TikTok)" : "អ្នកបង្កើតមាតិកាឌីជីថល (TikTok)",
      comment: currentLang === "en" ? "Absolutely unmatched service speeds! My TikTok views skyrocketed from 2K to 50K within minutes of ordering. Best SMM Panel in Cambodia!" : "ល្បឿនសេវាកម្មពិតជាមិនអាចរកកន្លែងប្រៀបផ្ទឹមបានទេ! ចំនួនមើល TikTok របស់ខ្ញុំបានហក់ឡើងពី ២ពាន់ ទៅ ៥ម៉ឺន ក្នុងរយៈពេលប៉ុន្មាននាទីបន្ទាប់ពីការបញ្ជាទិញ។ SMM Panel ល្អបំផុតនៅកម្ពុជា!",
      stars: 5,
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=100&h=100&q=80"
    },
    {
      name: "Srey Leak",
      role: currentLang === "en" ? "E-commerce Business Owner" : "ម្ចាស់អាជីវកម្មលក់ទំនិញអនឡាញ",
      comment: currentLang === "en" ? "I use Khmer Boost SMM daily to boost post traction on my Page. Highly secure, easy deposit scan, and instant results. Fully recommended!" : "ខ្ញុំប្រើប្រាស់ Khmer Boost SMM រាល់ថ្ងៃ ដើម្បីជួយជំរុញការលក់នៅលើផេករបស់ខ្ញុំ។ មានសុវត្ថិភាពខ្ពស់ ស្កេនទូទាត់លុយស្រួល និងលទ្ធផលរហ័សទាន់ចិត្ត។ ណែនាំទាំងស្រុង!",
      stars: 5,
      avatar: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&w=100&h=100&q=80"
    },
    {
      name: "Oun Chanra",
      role: currentLang === "en" ? "Music Streamer & Producer" : "អ្នកផ្សាយតន្ត្រី និងផលិតករ",
      comment: currentLang === "en" ? "API integrations are highly reliable. Programmatically placing orders via telemetry backend was a breeze. Rates per 1K are the cheapest here." : "ការភ្ជាប់ API ពិតជាគួរឱ្យទុកចិត្តណាស់។ បញ្ជាទិញដោយស្វ័យប្រវត្តិតាមរយៈប្រព័ន្ធកូដលឿនរលូន។ តម្លៃក្នុង ១ពាន់ គឺធូរថ្លៃបំផុតនៅទីនេះ។",
      stars: 5,
      avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=100&h=100&q=80"
    }
  ];

  // Pricing Cards Data definition
  const pricingPlans = [
    {
      name: "Starter Booster",
      price: "$9.99",
      period: "/mo",
      desc: currentLang === "en" ? "Perfect for micro-influencers." : "ល្អឥតខ្ចោះសាកសមសម្រាប់អ្នកបង្កើតមាតិកាតូចតាច។",
      features: [
        currentLang === "en" ? "Access to all Facebook/TikTok tools" : "ការផ្ដល់ជូនរាល់ឧបករណ៍ Facebook/TikTok ទាំងអស់",
        currentLang === "en" ? "Minimum boost orders starting from 100 units" : "ដែនកំណត់ទិញទាបបំផុតត្រឹម ១០០ គ្រឿង",
        currentLang === "en" ? "Standard speed processing" : "ល្បឿនដំណើរការធម្មតា",
        currentLang === "en" ? "24/7 client support ticket access" : "ក្រុមគាំទ្របច្ចេកទេស ២៤ ម៉ោង"
      ],
      popular: false
    },
    {
      name: "Viral Sensation",
      price: "$29.99",
      period: "/mo",
      desc: currentLang === "en" ? "Most popular for growing brands." : "ពេញនិយមបំផុតសម្រាប់ម៉ាកយីហោកំពុងរីកចម្រើន។",
      features: [
        currentLang === "en" ? "Preload $15 store credits included" : "ទទួលបានទឹកប្រាក់ហោប៉ៅ $15 ទុកប្រើប្រាស់ស្រាប់",
        currentLang === "en" ? "VIP SMM Server speeds option enabled" : "ជម្រើសល្បឿនដំណើរការលំដាប់ VIP ខ្ពស់បំផុត",
        currentLang === "en" ? "Lifetime warranty refill option for guarantee" : "ធានាបន្ថែមជំនួសពេញមួយជីវិតសម្រាប់ការធ្លាក់ចុះ",
        currentLang === "en" ? "Priority backend ticket assignment queue" : "ជួរដោះស្រាយលឿនរហ័សមុនគេ"
      ],
      popular: true
    },
    {
      name: "Elite Agency",
      price: "$89.99",
      period: "/mo",
      desc: currentLang === "en" ? "Custom setups for high-volume resellers." : "ការរៀបចំពិសេសសម្រាប់អ្នកលក់បន្តដុំធំ។",
      features: [
        currentLang === "en" ? "Exclusive API token endpoint connection" : "ការតភ្ជាប់ API Token ផ្តាច់មុខគ្មានដែនកំណត់",
        currentLang === "en" ? "20% Discount margins off standard catalogs" : "ការបញ្ចុះតម្លៃ ២០% បន្ថែមលើរាល់សេវាកម្មទាំងអស់",
        currentLang === "en" ? "Dedicated WhatsApp manager advisor" : "គ្រប់គ្រងផ្ទាល់តាមទូរស័ព្ទជាមួយទីប្រឹក្សា",
        currentLang === "en" ? "Overlord admin credentials setup simulator" : "គំរូសេវាកម្មលំដាប់កំពូល"
      ],
      popular: false
    }
  ];

  // FAQ accordion questions
  const faqs = [
    {
      q: currentLang === "en" ? "Is it safe to boost followers or active page likes?" : "តើការជំរុញអ្នកតាមដាន ឬអ្នកចូលចិត្តផេកមានសុវត្ថិភាពដែរឬទេ?",
      a: currentLang === "en" ? "100% Secure. Khmer Boost SMM complies strictly with strict security standard patterns. We utilize real accounts and organic delivery rates to protect your media profiles from platform algorithm bans." : "មានសុវត្ថិភាព ១០០%។ Khmer Boost SMM គោរពតាមបទដ្ឋានសុវត្ថិភាពតឹងរ៉ឹងបំផុត។ យើងប្រើប្រាស់គណនីជាក់ស្តែង និងល្បឿនចែកគម្លាតបែបធម្មជាតិ ដើម្បីការពារគណនីរបស់អ្នកពីការស្កេនរបស់បណ្តាញសង្គម។"
    },
    {
      q: currentLang === "en" ? "How long does it take for deposit funds to hit my account balance?" : "តើការបញ្ចូលទឹកប្រាក់បន្ថែមប្រើប្រាស់ពេលប៉ុន្មានទើបចូលសមតុល្យគណនី?",
      a: currentLang === "en" ? "Near instant. Once you transfer the accurate USD amount to our ABA, ACLEDA, or Wing KHQR, simply input your reference TXID. Our automated validation queue verifies and credits your wallet within 1 to 5 minutes maximum." : "ភ្លាមៗតែម្ដង។ នៅពេលអ្នកផ្ទេរប្រាក់ USD ត្រូវនឹងចំនួនទៅកាន់ ABA, ACLEDA ឬ Wing KHQR របស់យើង រួចផ្ញើលេខយោង TXID មក ប្រព័ន្ធស្វ័យប្រវត្តិនឹងដំណើរការផ្ទៀងផ្ទាត់បញ្ជូនថវិកាក្នុងរយៈពេលតែ ១ ទៅ ៥ នាទីប៉ុណ្ណោះ។"
    },
    {
      q: currentLang === "en" ? "What is the Lifetime Refill Guarantee (No-Drop)?" : "តើការធានាពេញមួយជីវិត (Lifetime Refill Guarantee) ជាអ្វី?",
      a: currentLang === "en" ? "For services marked with [Lifetime Warranty] or [No Drop], if platform algorithm cleaning causes a minor decline in followers/likes counts, you can click Refill or open a support ticket to instantly obtain replenishment units entirely for free." : "សម្រាប់សេវាកម្មដែលមានចំណាំ [ធានាពេញមួយជីវិត] ប្រសិនបើបណ្តាញសង្គមធ្វើបច្ចុប្បន្នភាពបណ្តាលឱ្យស្រកចំនួនតិចតួច អ្នកអាចចុច Refill ឬបើកសំបុត្រសំណូមពរដើម្បីឲ្យប្រព័ន្ធចាក់បំពេញបន្ថែមដោយឥតគិតថ្លៃ។"
    },
    {
      q: currentLang === "en" ? "Can I resell your services directly on my own panel website?" : "តើខ្ញុំអាចលក់បន្តសេវាកម្មរបស់អ្នកនៅលើគេហទំព័រផ្ទាល់ខ្លួនបានដែរឬទេ?",
      a: currentLang === "en" ? "Yes! Our robust JSON REST API endpoints are designed explicitly for resellers. Simply obtain your secure API key under our developer portal documentation and coordinate orders programmatically." : "បានយ៉ាងពិតប្រាកដ! ផ្លូវភ្ជាប់ REST API របស់ពួកយើងគឺរៀបចំយ៉ាងល្អសម្រាប់ការលក់បន្ត។ គ្រាន់តែទាញយក API Key របស់លោកអ្នកនៅក្នុងទំព័រឯកសារ API រួចដំឡើងការបញ្ជាទិញដោយស្វ័យប្រវត្តិ។"
    }
  ];

  return (
    <div id="landing-viewport" className="space-y-24 pb-16">
      
      {/* 1. HERO SECTION */}
      <section id="hero-section" className="relative pt-12 text-center max-w-4xl mx-auto px-4">
        
        {/* Glow backdrop circles */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -top-10 left-1/4 h-80 w-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative space-y-6">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-xs font-bold text-purple-400">
            <Radio size={12} className="text-purple-400 animate-pulse" />
            <span className="font-display tracking-wider uppercase">{currentLang === "en" ? "⚡ Auto-Delivery Pipeline Active" : "⚡ សេវាកម្មដំណើរការស្វ័យប្រវត្ត ២៤ម៉ោង"}</span>
          </div>

          <h1 className="text-4xl md:text-6xl font-black font-display tracking-tight text-white leading-[1.1] text-glow">
            {t.tagline}
          </h1>

          <p className="text-sm md:text-base text-slate-350 max-w-2xl mx-auto leading-relaxed font-sans">
            {t.description}
          </p>

          <div className="flex flex-col sm:flex-row justify-center items-center gap-3.5 pt-4">
            <button
              onClick={onNavigateToRegister}
              className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-purple-950/40 hover:shadow-purple-500/30 transition-all cursor-pointer flex items-center justify-center space-x-2 text-sm"
            >
              <span>{t.heroActionBuy}</span>
              <ArrowRight size={16} />
            </button>
            
            <button
              onClick={onNavigateToServices}
              className="w-full sm:w-auto px-8 py-4 bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white font-bold rounded-xl transition cursor-pointer flex items-center justify-center text-sm"
            >
              <span>{t.heroActionServices}</span>
            </button>
          </div>

          {/* Quick Metrics stats */}
          <div className="grid grid-cols-3 gap-4 max-w-2xl mx-auto pt-16 border-t border-slate-900/60 font-display">
            <div>
              <div className="text-xl md:text-3xl font-extrabold text-white">45,000+</div>
              <div className="text-[10px] uppercase font-bold tracking-widest text-slate-500 mt-1">{t.heroStatsUsers}</div>
            </div>
            <div>
              <div className="text-xl md:text-3xl font-extrabold text-purple-400">1,240,580+</div>
              <div className="text-[10px] uppercase font-bold tracking-widest text-slate-500 mt-1">{t.heroStatsCompleted}</div>
            </div>
            <div>
              <div className="text-xl md:text-3xl font-extrabold text-emerald-400">99.8%</div>
              <div className="text-[10px] uppercase font-bold tracking-widest text-slate-500 mt-1">{t.heroStatsRating}</div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. CHOOSE SPECIFIC PLATFORM AND CHOOSE SMM CATALOG SHOWCASE */}
      <section id="landing-showcase-section" className="space-y-8 px-4 max-w-5xl mx-auto">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold font-display tracking-tight text-white">{t.servPlatform}</h2>
          <p className="text-sm text-slate-400 leading-relaxed max-w-xl mx-auto">{t.servSub}</p>
        </div>

        {/* Selected Category tabs selector */}
        <div className="flex justify-center items-center gap-2 max-w-md mx-auto">
          {[
            { id: "facebook", name: "Facebook", icon: Facebook, color: "text-blue-400", activeBg: "bg-blue-500/10 border-blue-500/20 text-blue-400" },
            { id: "tiktok", name: "TikTok", icon: Video, color: "text-rose-400", activeBg: "bg-rose-500/10 border-rose-500/20 text-rose-450" },
            { id: "telegram", name: "Telegram", icon: IconTelegram, color: "text-sky-400", activeBg: "bg-sky-500/10 border-sky-500/20 text-sky-400" },
            { id: "youtube", name: "YouTube", icon: Youtube, color: "text-red-500", activeBg: "bg-red-500/11 border-red-500/20 text-red-500" }
          ].map((cat) => {
            const CatIcon = cat.icon;
            const isActive = selectedCat === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCat(cat.id as any)}
                className={`flex-1 p-3.5 rounded-xl border flex flex-col items-center gap-1.5 transition duration-200 cursor-pointer text-center ${
                  isActive 
                    ? cat.activeBg + " shadow-md" 
                    : "bg-slate-950/40 border-slate-900 hover:border-slate-800 text-slate-400 hover:text-slate-350"
                }`}
              >
                <CatIcon size={20} className={cat.color} />
                <span className="text-[10px] font-bold font-display">{cat.name}</span>
              </button>
            );
          })}
        </div>

        {/* Catalog lists */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredSample.map((srv) => (
            <div
              key={srv.id}
              className="p-5 rounded-2xl glass-panel border border-slate-900 hover:border-slate-800/80 transition glow-border space-y-4"
            >
              <div className="flex justify-between items-start gap-4">
                <div>
                  <span className="px-2.5 py-0.5 text-[8px] font-black tracking-widest text-purple-400 bg-purple-500/10 rounded uppercase">
                    {srv.platform}
                  </span>
                  <h4 className="text-xs font-extrabold text-slate-100 mt-2 font-display">
                    {currentLang === "en" ? srv.nameEn : srv.nameKm}
                  </h4>
                </div>
                {/* Rate card price */}
                <div className="text-right shrink-0">
                  <div className="text-xs font-black font-mono text-emerald-400">${srv.rateEn.toFixed(2)}</div>
                  <div className="text-[8px] text-slate-500 font-bold uppercase tracking-wider mt-0.5">{t.servRate}</div>
                </div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed font-sans mt-2">
                {currentLang === "en" ? srv.descriptionEn : srv.descriptionKm}
              </p>

              <div className="flex items-center justify-between border-t border-slate-900 pt-3">
                <span className="text-[10px] font-mono text-slate-500">
                  {currentLang === "en" ? "Min Bounds:" : "ទិញតិចបំផុត:"} {srv.minQuantity.toLocaleString()}
                </span>
                <button
                  onClick={onNavigateToLogin}
                  className="text-[10px] font-bold text-purple-400 hover:text-purple-300 flex items-center space-x-0.5 cursor-pointer"
                >
                  <span>{currentLang === "en" ? "Order Boost" : "បញ្ជាទិញ Boost"}</span>
                  <ArrowRight size={10} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. PRICING MODES */}
      <section id="pricing-tier-section" className="space-y-12 px-4 max-w-5xl mx-auto">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-black font-display tracking-tight text-glow text-white">
            {currentLang === "en" ? "Highly Affordable Tier Packages" : "កញ្ចប់តម្លៃសេវាកម្មដ៏សមរម្យ"}
          </h2>
          <p className="text-sm text-slate-400 max-w-xl mx-auto">
            {currentLang === "en" ? "Choose a boost tier layout to fit your promotional target sizing." : "ជ្រើសរើសជម្រើសកម្រិតជំរុញសក្ដិសមនឹងទំហំក្រុមការងាររបស់លោកអ្នក។"}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {pricingPlans.map((plan, i) => (
            <div
              key={i}
              className={`p-6 rounded-3xl relative overflow-hidden flex flex-col justify-between ${
                plan.popular
                  ? "bg-gradient-to-b from-slate-900 to-indigo-950/60 border border-purple-500/30 shadow-xl shadow-purple-950/30"
                  : "glass-panel border-slate-900"
              }`}
            >
              {plan.popular && (
                <span className="absolute top-3 right-3 px-2.5 py-0.5 text-[8px] font-black uppercase tracking-widest bg-purple-500 text-white rounded-full">
                  Popular
                </span>
              )}

              <div>
                <h4 className="text-sm font-black text-slate-200 tracking-wide font-display">{plan.name}</h4>
                <p className="text-[11px] text-slate-400 mt-1">{plan.desc}</p>

                <div className="mt-4 flex items-baseline select-all">
                  <span className="text-3xl font-black font-mono text-white text-glow">{plan.price}</span>
                  <span className="text-xs text-slate-500 font-sans ml-1 font-semibold">{plan.period}</span>
                </div>

                {/* Features list */}
                <ul className="mt-6 space-y-3 font-sans text-xs text-slate-350">
                  {plan.features.map((feat, fId) => (
                    <li key={fId} className="flex items-start">
                      <Check size={14} className="text-purple-400 mt-0.5 mr-2 shrink-0" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-8">
                <button
                  onClick={onNavigateToRegister}
                  className={`w-full py-2.5 text-xs font-bold rounded-xl transition cursor-pointer text-center ${
                    plan.popular
                      ? "bg-purple-600 hover:bg-purple-500 text-white shadow-md shadow-purple-900/40"
                      : "bg-slate-950 border border-slate-850 hover:border-slate-800 text-slate-400 hover:text-white"
                  }`}
                >
                  {currentLang === "en" ? "Deploy Now" : "ដំណើរការឥឡូវនេះ"}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. CUSTOMER REVIEWS */}
      <section id="customer-reviews-section" className="space-y-12 px-4 max-w-5xl mx-auto">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold font-display text-white">{t.revTitle}</h2>
          <p className="text-xs text-slate-400 max-w-xl mx-auto">{t.revSub}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {reviews.map((rev, idx) => (
            <div
              key={idx}
              className="p-5 rounded-2xl glass-panel border border-slate-900/90 hover:border-slate-800 flex flex-col justify-between space-y-4 font-sans"
            >
              <div className="space-y-3">
                <div className="flex gap-1">
                  {[...Array(rev.stars)].map((_, s) => (
                    <Star key={s} size={14} className="fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed italic select-all">&quot;{rev.comment}&quot;</p>
              </div>

              <div className="flex items-center space-x-3 pt-3 border-t border-slate-900">
                <img
                  src={rev.avatar}
                  alt={rev.name}
                  className="w-9 h-9 rounded-full object-cover border border-purple-500/30"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="text-xs font-extrabold text-slate-100 font-display">{rev.name}</h4>
                  <p className="text-[9px] text-slate-500 mt-0.5">{rev.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. FAQ SECTION Accordion */}
      <section id="faq-accordions-section" className="max-w-3xl mx-auto px-4 space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold font-display tracking-tight text-white mb-2">{t.faqTitle}</h2>
          <p className="text-xs text-slate-400 max-w-xl mx-auto">{t.faqSub}</p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, i) => {
            const isOpen = faqOpenIdx === i;
            return (
              <div
                key={i}
                className="rounded-2xl glass-panel border border-slate-900 overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => setFaqOpenIdx(isOpen ? null : i)}
                  className="w-full p-5 flex items-center justify-between text-left font-sans cursor-pointer hover:bg-slate-950/20 transition"
                >
                  <span className="text-xs md:text-sm font-bold text-slate-200 pr-4">{faq.q}</span>
                  <ChevronDown size={16} className={`text-slate-450 transition duration-300 ${isOpen ? "rotate-180 text-purple-400" : ""}`} />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs text-slate-400 leading-relaxed border-t border-slate-900 font-sans">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 6. IMMERSIVE BRAND FOOTER */}
      <footer id="brand-footer" className="p-8 md:p-12 background-slate-950 border-t border-slate-900 leading-relaxed text-xs">
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 text-slate-350 font-sans">
          
          <div className="md:col-span-6 space-y-3">
            <div className="text-base font-extrabold text-white tracking-widest font-display text-glow">{t.brandName}</div>
            <p className="text-[11px] text-slate-440 max-w-md">{t.footText}</p>
            <div className="text-[10px] text-slate-500 font-mono mt-4">© 2026 KHMER BOOST SMM CO., LTD. Cambodia Social Boosting Services. All rights reserved.</div>
          </div>

          <div className="md:col-span-3 space-y-2">
            <h4 className="text-xs font-extrabold text-white uppercase tracking-wider font-display">{t.footLinks}</h4>
            <ul className="space-y-1.5 text-[11px] font-medium text-slate-400">
              <li><button onClick={onNavigateToServices} className="hover:text-purple-400 cursor-pointer">SMM Services Catalog</button></li>
              <li><button onClick={onNavigateToLogin} className="hover:text-purple-400 cursor-pointer">SMM User Dashboard</button></li>
              <li><button onClick={onNavigateToRegister} className="hover:text-purple-400 cursor-pointer">Register Free Account</button></li>
            </ul>
          </div>

          <div className="md:col-span-3 space-y-2">
            <h4 className="text-xs font-extrabold text-white uppercase tracking-wider font-display">{t.footSocial}</h4>
            <div className="text-[11px] text-slate-400">
              {currentLang === "en" ? "Need help? Contact live Telegram channel:" : "ត្រូវការសួរនាំសូមទាក់ទងឆានែលតេឡេក្រាម៖"}
            </div>
            <a
              href="https://t.me/khmerboostsmm"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-sky-500/10 border border-sky-500/20 text-sky-400 hover:text-white hover:bg-sky-500/20 transition mt-2 font-mono"
            >
              <IconTelegram size={12} />
              <span>@khmerboostsmm</span>
            </a>
          </div>

        </div>
      </footer>
    </div>
  );
}
