import React from "react";

interface LanguageSelectorProps {
  currentLang: "en" | "km";
  setLang: (lang: "en" | "km") => void;
}

export default function LanguageSelector({ currentLang, setLang }: LanguageSelectorProps) {
  return (
    <div id="lang-selector-container" className="inline-flex rounded-lg p-0.5 bg-slate-900 border border-slate-800">
      <button
        id="btn-lang-en"
        onClick={() => setLang("en")}
        className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all duration-200 cursor-pointer ${
          currentLang === "en"
            ? "bg-purple-600 text-white shadow-md shadow-purple-900/40"
            : "text-slate-400 hover:text-white"
        }`}
      >
        🇺🇸 EN
      </button>
      <button
        id="btn-lang-km"
        onClick={() => setLang("km")}
        className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all duration-200 cursor-pointer ${
          currentLang === "km"
            ? "bg-purple-600 text-white shadow-md shadow-purple-900/40"
            : "text-slate-400 hover:text-white"
        }`}
      >
        🇰🇭 KM
      </button>
    </div>
  );
}
