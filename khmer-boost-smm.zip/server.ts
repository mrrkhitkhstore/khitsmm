import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { SMMService, SMMOrder, UserSession, Transaction, SupportMessage } from "./src/types.js";

// Database File Path
const DB_PATH = path.join(process.cwd(), "smm_db.json");

// Structure of SMM JSON database
interface SMMDatabase {
  users: Array<UserSession & { passwordHash: string }>;
  services: SMMService[];
  orders: SMMOrder[];
  transactions: Transaction[];
  tickets: SupportMessage[];
}

// Default initial services
const DEFAULT_SERVICES: SMMService[] = [
  {
    id: "fb-likes-01",
    category: "facebook",
    nameEn: "Facebook Profile/Page Likes [Fast Speed, 30 Days Guarantee]",
    nameKm: "អ្នកចូលចិត្តទំព័រ/គណនីហ្វេសប៊ុក [ល្បឿនលឿន, ធានា ៣០ ថ្ងៃ]",
    rateEn: 1.45,
    minQuantity: 100,
    maxQuantity: 50000,
    descriptionEn: "High-quality active Facebook profiles. Guaranteed refill speed within 24 hours.",
    descriptionKm: "ប្រវត្តិរូបហ្វេសប៊ុកសកម្មមានគុណភាពខ្ពស់។ ធានាបន្ថែមក្នុងកំឡុងពេល ២៤ ម៉ោង។",
    platform: "Facebook"
  },
  {
    id: "fb-followers-02",
    category: "facebook",
    nameEn: "Facebook Real VIP Profile Followers [No Drop, Lifetime Warranty]",
    nameKm: "អ្នកតាមដានគណនីហ្វេសប៊ុកពិតៗ VIP [មិនមានការថយចុះ, ធានាពេញមួយជីវិត]",
    rateEn: 1.80,
    minQuantity: 100,
    maxQuantity: 25000,
    descriptionEn: "Organic looking followers. Steady delivery of 2K-5K per day for premium safety.",
    descriptionKm: "អ្នកតាមដានមើលទៅបែបធម្មជាតិ។ ការដឹកជញ្ជូនថេរ ២,០០០ ទៅ ៥,០០០ នាក់ក្នុងមួយថ្ងៃ ដើម្បីសុវត្ថិភាពខ្ពស់។",
    platform: "Facebook"
  },
  {
    id: "tiktok-views-01",
    category: "tiktok",
    nameEn: "TikTok Video Views [Super Instant Speed, Unlimited]",
    nameKm: "អ្នកទស្សនាវីដេអូ TikTok [ល្បឿនលឿនភ្លាមៗ, មិនមានដែនកំណត់]",
    rateEn: 0.12,
    minQuantity: 500,
    maxQuantity: 1000000,
    descriptionEn: "Instant start within 1 minute. Enhances viral algorithm indexing.",
    descriptionKm: "ផ្ដើមក្នុងរយៈពេល ១ នាទី។ ជួយជម្រុញសន្ទស្សន៍ក្បួនដោះស្រាយវីដេអូឱ្យល្បីល្បាញ។",
    platform: "TikTok"
  },
  {
    id: "tiktok-followers-02",
    category: "tiktok",
    nameEn: "TikTok Premium Real Followers [Refill Guarantee]",
    nameKm: "អ្នកតាមដានគណនី TikTok ពិតៗកម្រិតលំដាប់ខ្ពស់ [មានការធានាបន្ថែមជំនួសវិញ]",
    rateEn: 2.20,
    minQuantity: 100,
    maxQuantity: 10000,
    descriptionEn: "Real looking accounts with postings. Boosts TikTok shop eligibility criteria.",
    descriptionKm: "គណនីពិតៗដែលមានការបង្ហោះវីដេអូ។ ជួយដល់លក្ខខណ្ឌសិទ្ធិបង្កើត TikTok Shop។",
    platform: "TikTok"
  },
  {
    id: "tele-members-01",
    category: "telegram",
    nameEn: "Telegram Channel/Group Members [Ultra Stable, No Drop]",
    nameKm: "សមាជិកប៉ុស្តិ៍/ក្រុមតេឡេក្រាម [ស្ថិរភាពខ្ពស់បំផុត, មិនស្រក]",
    rateEn: 0.95,
    minQuantity: 200,
    maxQuantity: 30000,
    descriptionEn: "Excellent for crypto channels, promotions, and shop portals. High retention rate.",
    descriptionKm: "ល្អបំផុតសម្រាប់ប៉ុស្តិ៍គ្រីបតូ ការផ្សព្វផ្សាយ និងទំព័រហាង។ អត្រារក្សាទុកខ្ពស់។",
    platform: "Telegram"
  },
  {
    id: "yt-views-01",
    category: "youtube",
    nameEn: "YouTube Monetization Views [Gradual Drip-Feed, High Retention]",
    nameKm: "អ្នកទស្សនាវីដេអូ YouTube រកលុយ [ចែកគម្លាតបន្តិចម្ដងៗ, រក្សាទុកខ្ពស់]",
    rateEn: 1.95,
    minQuantity: 200,
    maxQuantity: 100000,
    descriptionEn: "Non-drop monetization safe views. Watching time ranges from 3-10 minutes.",
    descriptionKm: "អ្នកទស្សនាមានសុវត្ថិភាពសម្រាប់ការរកលុយ។ រយៈពេលទស្សនាចន្លោះពី ៣ ទៅ ១០ នាទី។",
    platform: "YouTube"
  },
  {
    id: "yt-subs-02",
    category: "youtube",
    nameEn: "YouTube Permanent Real Subscribers [Strict Lifetime Refill]",
    nameKm: "អ្នកជាវប្រចាំប៉ុស្តិ៍ YouTube [ធានាពេញមួយជីវិតពិតប្រាកដ]",
    rateEn: 8.90,
    minQuantity: 50,
    maxQuantity: 10000,
    descriptionEn: "Guaranteed organic-mix subscribers. Fast activation, 100-300 per day rate.",
    descriptionKm: "ធានាអ្នកជាវចម្រុះបែបធម្មជាតិ។ ដំណើរការរហ័ស ១០០ ទៅ ៣០០ នាក់ក្នុងមួយថ្ងៃ។",
    platform: "YouTube"
  }
];

// Load Database
function loadDB(): SMMDatabase {
  if (!fs.existsSync(DB_PATH)) {
    const initialConfig: SMMDatabase = {
      users: [
        {
          id: "sys-admin-kboost",
          email: "mrrkhitkh@gmail.com",
          username: "Administrator",
          balance: 650.00,
          role: "admin",
          createdAt: new Date().toISOString(),
          passwordHash: "boostpass123" // Simple secure comparison
        }
      ],
      services: DEFAULT_SERVICES,
      orders: [],
      transactions: [],
      tickets: []
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(initialConfig, null, 2), "utf-8");
    return initialConfig;
  }
  
  try {
    const data = fs.readFileSync(DB_PATH, "utf-8");
    return JSON.parse(data);
  } catch (err) {
    console.error("Error loading db, resetting to default", err);
    return {
      users: [],
      services: DEFAULT_SERVICES,
      orders: [],
      transactions: [],
      tickets: []
    };
  }
}

// Save Database
function saveDB(data: SMMDatabase) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving database", err);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;
  
  app.use(express.json());
  
  // CORS fallback security
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  // Token helper: Simple stateful session validator
  const sessionsMap = new Map<string, string>(); // Token -> userEmail

  // Middleware to authenticate user
  const authenticateUser = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Unauthorized session. Please sign in." });
    }
    const token = authHeader.split(" ")[1];
    const email = sessionsMap.get(token);
    if (!email) {
      return res.status(401).json({ error: "Session expired or invalid. Access denied." });
    }
    
    const db = loadDB();
    const user = db.users.find(u => u.email === email);
    if (!user) {
      return res.status(401).json({ error: "User record deleted." });
    }
    
    // Inject user into request
    (req as any).user = user;
    (req as any).token = token;
    next();
  };

  // Middleware to authenticate admin
  const authenticateAdmin = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    authenticateUser(req, res, () => {
      const u = (req as any).user;
      if (u.role !== "admin") {
        return res.status(403).json({ error: "Forbidden. Admin privilege required." });
      }
      next();
    });
  };

  // ---------------- AUTH ROUTES ----------------

  // Register
  app.post("/api/auth/register", (req, res) => {
    const { email, username, password } = req.body;
    if (!email || !username || !password) {
      return res.status(400).json({ error: "Please enter your email, username, and password." });
    }

    const emailStr = String(email).trim().toLowerCase();
    const userStr = String(username).trim();

    const db = loadDB();
    if (db.users.find(u => u.email === emailStr)) {
      return res.status(400).json({ error: "This email address is already registered." });
    }

    // Determine role (first user or requested developer email is Admin)
    const isFirstUser = db.users.length === 0;
    const isSpecialEmail = emailStr === "mrrkhitkh@gmail.com";
    const role: "user" | "admin" = (isFirstUser || isSpecialEmail) ? "admin" : "user";

    const newUser = {
      id: "usr-" + Math.random().toString(36).substring(2, 9),
      email: emailStr,
      username: userStr,
      balance: isSpecialEmail ? 500.00 : 0.00, // Preload $500 balance for the developer email
      role,
      createdAt: new Date().toISOString(),
      passwordHash: password // Plain comparison for visual environment simulation
    };

    db.users.push(newUser);
    saveDB(db);

    // Auto log in after registration
    const token = "tok-" + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    sessionsMap.set(token, emailStr);

    const { passwordHash, ...safeUser } = newUser;
    return res.status(201).json({
      message: "Registration successful. Welcome to Khmer Boost SMM!",
      token,
      user: safeUser
    });
  });

  // Login
  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "Required fields are missing." });
    }

    const emailStr = String(email).trim().toLowerCase();
    const db = loadDB();
    const user = db.users.find(u => u.email === emailStr);

    if (!user || user.passwordHash !== password) {
      return res.status(400).json({ error: "Invalid email or password combination." });
    }

    // Generate token
    const token = "tok-" + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    sessionsMap.set(token, emailStr);

    const { passwordHash, ...safeUser } = user;
    return res.json({
      message: "Sign in successful.",
      token,
      user: safeUser
    });
  });

  // Authenticated me
  app.get("/api/auth/me", authenticateUser, (req, res) => {
    const u = (req as any).user;
    const { passwordHash, ...safeUser } = u;
    return res.json({ user: safeUser });
  });

  // Force reset / forgot password simulation
  app.post("/api/auth/reset-password", (req, res) => {
    const { email, newPassword } = req.body;
    if (!email || !newPassword) {
      return res.status(400).json({ error: "Please enter your registered email and a new password." });
    }
    const emailStr = String(email).trim().toLowerCase();
    const db = loadDB();
    const userIndex = db.users.findIndex(u => u.email === emailStr);
    if (userIndex === -1) {
      return res.status(400).json({ error: "No user found with this email address." });
    }

    db.users[userIndex].passwordHash = newPassword;
    saveDB(db);

    return res.json({ message: "Password updated successfully. Please log in with your new credential." });
  });


  // ---------------- GENERAL SERVICES ----------------

  // Get active catalogs
  app.get("/api/services", (req, res) => {
    const db = loadDB();
    const category = req.query.category;
    if (category && category !== "all") {
      const filtered = db.services.filter(s => s.category === category);
      return res.json(filtered);
    }
    return res.json(db.services);
  });


  // ---------------- MY ORDERS ----------------

  // Create new order
  app.post("/api/orders", authenticateUser, (req, res) => {
    const { serviceId, link, quantity } = req.body;
    const currentUser = (req as any).user;
    
    if (!serviceId || !link || !quantity) {
      return res.status(400).json({ error: "Please provide target service, profile/video link, and total booster quantity." });
    }

    const qty = parseInt(quantity, 10);
    if (isNaN(qty) || qty <= 0) {
      return res.status(400).json({ error: "Please input a valid positive quantity range." });
    }

    const db = loadDB();
    const service = db.services.find(s => s.id === serviceId);
    if (!service) {
      return res.status(404).json({ error: "Premium SMM service not found." });
    }

    if (qty < service.minQuantity || qty > service.maxQuantity) {
      return res.status(400).json({
        error: `Order quantity is outside of index boundaries. Must be between ${service.minQuantity} and ${service.maxQuantity}.`
      });
    }

    const charge = parseFloat(((qty / 1000) * service.rateEn).toFixed(4));
    
    // Find live user in database to update core balance
    const userRecord = db.users.find(u => u.id === currentUser.id);
    if (!userRecord) {
      return res.status(404).json({ error: "Booster credentials not found in live scope." });
    }

    if (userRecord.balance < charge) {
      return res.status(400).json({
        error: `Insufficient account balance. This action requires $${charge.toFixed(3)} USD, but you only have $${userRecord.balance.toFixed(3)} USD.`
      });
    }

    // Deduct balance
    userRecord.balance = parseFloat((userRecord.balance - charge).toFixed(4));

    // Place SMM Order
    const newOrder: SMMOrder = {
      id: "ord-" + Math.random().toString(36).substring(2, 9).toUpperCase(),
      userId: userRecord.id,
      userEmail: userRecord.email,
      serviceId: service.id,
      serviceName: service.nameEn,
      platform: service.platform,
      link: String(link).trim(),
      quantity: qty,
      charge,
      status: "processing", // Let's make it 'processing' instantly meaning it is in high gear!
      createdAt: new Date().toISOString()
    };

    db.orders.push(newOrder);
    saveDB(db);

    return res.status(201).json({
      message: "Order launched successfully! Watch the stats rise in real-time.",
      order: newOrder,
      newBalance: userRecord.balance
    });
  });

  // Get current user orders or get all if admin and queried
  app.get("/api/orders/my", authenticateUser, (req, res) => {
    const currentUser = (req as any).user;
    const db = loadDB();
    const myOrders = db.orders.filter(o => o.userId === currentUser.id);
    return res.json(myOrders.reverse()); // Show newest first
  });


  // ---------------- TRANSACTIONS (DEPOSITS) ----------------

  // Submit payment receipt proof
  app.post("/api/transactions", authenticateUser, (req, res) => {
    const { amount, bank, transactionId } = req.body;
    const currentUser = (req as any).user;

    if (!amount || !bank || !transactionId) {
      return res.status(400).json({ error: "Missing required cash receipt credentials. Submit amount, bank name, and TXID." });
    }

    const value = parseFloat(amount);
    if (isNaN(value) || value <= 0) {
      return res.status(400).json({ error: "Specify a valid numeric deposit amount in US Dollars." });
    }

    const b = String(bank).toLowerCase();
    if (b !== "aba" && b !== "acleda" && b !== "wing") {
      return res.status(400).json({ error: "Select one of our authorized gateways: ABA, ACLEDA, or Wing." });
    }

    const db = loadDB();

    // Check pre-existence of TXID to guarantee anti-spam
    const duplicate = db.transactions.find(t => t.transactionId.trim().toLowerCase() === String(transactionId).trim().toLowerCase());
    if (duplicate) {
      return res.status(400).json({ error: "This transaction reference has already been submitted for verification." });
    }

    const newTransaction: Transaction = {
      id: "tx-" + Math.random().toString(36).substring(2, 9).toUpperCase(),
      userId: currentUser.id,
      userEmail: currentUser.email,
      amount: value,
      bank: b as "aba" | "acleda" | "wing",
      transactionId: String(transactionId).trim(),
      status: "pending",
      createdAt: new Date().toISOString()
    };

    db.transactions.push(newTransaction);
    saveDB(db);

    return res.status(201).json({
      message: "Payment voucher submitted successfully. Our support office will verify. Keep your banking proof ready.",
      transaction: newTransaction
    });
  });

  // See user's payment records
  app.get("/api/transactions/my", authenticateUser, (req, res) => {
    const currentUser = (req as any).user;
    const db = loadDB();
    const myTxList = db.transactions.filter(t => t.userId === currentUser.id);
    return res.json(myTxList.reverse());
  });


  // ---------------- TECHNICAL SUPPORT ----------------

  // Open support ticket
  app.post("/api/tickets", authenticateUser, (req, res) => {
    const { subject, message } = req.body;
    const currentUser = (req as any).user;

    if (!subject || !message) {
      return res.status(400).json({ error: "Fields cannot be blank. Enter ticket subject topic and message details." });
    }

    const db = loadDB();
    const newTicket: SupportMessage = {
      id: "tkt-" + Math.random().toString(36).substring(2, 9),
      userId: currentUser.id,
      userEmail: currentUser.email,
      subject: String(subject).trim(),
      message: String(message).trim(),
      status: "open",
      createdAt: new Date().toISOString()
    };

    db.tickets.push(newTicket);
    saveDB(db);

    return res.status(201).json({
      message: "Ticket registered. Engineers will respond within minutes.",
      ticket: newTicket
    });
  });

  // Get my support tickets
  app.get("/api/tickets/my", authenticateUser, (req, res) => {
    const currentUser = (req as any).user;
    const db = loadDB();
    const myTickets = db.tickets.filter(t => t.userId === currentUser.id);
    return res.json(myTickets.reverse());
  });


  // ---------------- ADMIN ACTIONS (STRICT) ----------------

  // Statistics Dashboard overview
  app.get("/api/admin/stats", authenticateAdmin, (req, res) => {
    const db = loadDB();
    const totalSales = db.orders.reduce((sum, o) => sum + o.charge, 0);
    const totalOrders = db.orders.length;
    const totalUsers = db.users.length;
    const pendingTransCount = db.transactions.filter(t => t.status === "pending").length;

    return res.json({
      totalSales,
      totalOrders,
      totalUsers,
      pendingTransCount
    });
  });

  // Users overview
  app.get("/api/admin/users", authenticateAdmin, (req, res) => {
    const db = loadDB();
    const safeUsers = db.users.map(({ passwordHash, ...safe }) => safe);
    return res.json(safeUsers);
  });

  // Update user budget/balance or role status
  app.put("/api/admin/users/:userId", authenticateAdmin, (req, res) => {
    const { userId } = req.params;
    const { balance, role } = req.body;
    
    const db = loadDB();
    const userIdx = db.users.findIndex(u => u.id === userId);
    if (userIdx === -1) {
      return res.status(404).json({ error: "Client matching requested ID is missing in database." });
    }

    if (balance !== undefined) {
      const bFloat = parseFloat(balance);
      if (!isNaN(bFloat)) {
        db.users[userIdx].balance = parseFloat(bFloat.toFixed(4));
      }
    }

    if (role !== undefined && (role === "user" || role === "admin")) {
      db.users[userIdx].role = role;
    }

    saveDB(db);
    const { passwordHash, ...safe } = db.users[userIdx];
    return res.json({ message: "Client profile successfully modified in core.", user: safe });
  });

  // Direct cash transfer approval
  app.post("/api/admin/transactions/:txId/resolve", authenticateAdmin, (req, res) => {
    const { txId } = req.params;
    const { action } = req.body; // "approve" or "reject"

    if (action !== "approve" && action !== "reject") {
      return res.status(400).json({ error: "Invalid resolution action. Choose approve or reject." });
    }

    const db = loadDB();
    const tx = db.transactions.find(t => t.id === txId);
    if (!tx) {
      return res.status(404).json({ error: "Submitted cash receipt ticket not found." });
    }

    if (tx.status !== "pending") {
      return res.status(400).json({ error: `Transaction has already been finalized/resolved as ${tx.status}.` });
    }

    if (action === "approve") {
      tx.status = "approved";
      // Fetch user profile and append funds
      const user = db.users.find(u => u.id === tx.userId);
      if (user) {
        user.balance = parseFloat((user.balance + tx.amount).toFixed(4));
      }
    } else {
      tx.status = "rejected";
    }

    saveDB(db);
    return res.json({ message: `Voucher successfully resolved as ${action.toUpperCase()}`, transaction: tx });
  });

  // SMM catalog management
  app.post("/api/admin/services", authenticateAdmin, (req, res) => {
    const { category, nameEn, nameKm, rateEn, minQuantity, maxQuantity, descriptionEn, descriptionKm, platform } = req.body;
    if (!category || !nameEn || !nameKm || !rateEn || !minQuantity || !maxQuantity || !platform) {
      return res.status(400).json({ error: "Required service definition fields are blank." });
    }

    const minQ = parseInt(minQuantity, 10);
    const maxQ = parseInt(maxQuantity, 10);
    const rate = parseFloat(rateEn);

    if (isNaN(minQ) || isNaN(maxQ) || isNaN(rate)) {
      return res.status(400).json({ error: "Min, Max and Rates must be accurate numerical parameters." });
    }

    const db = loadDB();
    const newService: SMMService = {
      id: "srv-" + Math.random().toString(36).substring(2, 9),
      category: category as any,
      nameEn,
      nameKm,
      rateEn: rate,
      minQuantity: minQ,
      maxQuantity: maxQ,
      descriptionEn: descriptionEn || "",
      descriptionKm: descriptionKm || "",
      platform: platform as any
    };

    db.services.push(newService);
    saveDB(db);

    return res.status(201).json({ message: "Catalog item saved successfully.", service: newService });
  });

  // Edit / Update SMM Service Catalog
  app.put("/api/admin/services/:id", authenticateAdmin, (req, res) => {
    const { id } = req.params;
    const updates = req.body;
    
    const db = loadDB();
    const serviceIndex = db.services.findIndex(s => s.id === id);
    if (serviceIndex === -1) {
      return res.status(404).json({ error: "Service catalog not found." });
    }

    const targetService = db.services[serviceIndex];
    
    if (updates.nameEn !== undefined) targetService.nameEn = updates.nameEn;
    if (updates.nameKm !== undefined) targetService.nameKm = updates.nameKm;
    if (updates.rateEn !== undefined) targetService.rateEn = parseFloat(updates.rateEn);
    if (updates.minQuantity !== undefined) targetService.minQuantity = parseInt(updates.minQuantity, 10);
    if (updates.maxQuantity !== undefined) targetService.maxQuantity = parseInt(updates.maxQuantity, 10);
    if (updates.descriptionEn !== undefined) targetService.descriptionEn = updates.descriptionEn;
    if (updates.descriptionKm !== undefined) targetService.descriptionKm = updates.descriptionKm;
    if (updates.category !== undefined) targetService.category = updates.category;
    if (updates.platform !== undefined) targetService.platform = updates.platform;

    saveDB(db);
    return res.json({ message: "Service catalog updated successfully.", service: targetService });
  });

  // Delete SMM service catalog
  app.delete("/api/admin/services/:id", authenticateAdmin, (req, res) => {
    const { id } = req.params;
    const db = loadDB();
    const initialLen = db.services.length;
    db.services = db.services.filter(s => s.id !== id);
    if (db.services.length === initialLen) {
      return res.status(404).json({ error: "SMM catalog item matching ID not found." });
    }
    saveDB(db);
    return res.json({ message: "Catalog item deleted successfully." });
  });

  // Get all system orders with user data
  app.get("/api/admin/orders", authenticateAdmin, (req, res) => {
    const db = loadDB();
    return res.json(db.orders.reverse());
  });

  // Modify order status (canceled, completed, pending, etc.)
  app.put("/api/admin/orders/:orderId", authenticateAdmin, (req, res) => {
    const { orderId } = req.params;
    const { status } = req.body; // pending, processing, completed, canceled

    if (!["pending", "processing", "completed", "canceled"].includes(status)) {
      return res.status(400).json({ error: "Invalid status parameters specified." });
    }

    const db = loadDB();
    const order = db.orders.find(o => o.id === orderId);
    if (!order) {
      return res.status(404).json({ error: "SMM Order payload not found." });
    }

    order.status = status;
    saveDB(db);

    return res.json({ message: "Order status successfully updated across booster pipelines.", order });
  });

  // Get all payment transaction tickets
  app.get("/api/admin/transactions", authenticateAdmin, (req, res) => {
    const db = loadDB();
    return res.json(db.transactions.reverse());
  });

  // Get all support tickets
  app.get("/api/admin/tickets", authenticateAdmin, (req, res) => {
    const db = loadDB();
    return res.json(db.tickets.reverse());
  });

  // Reply to support ticket
  app.post("/api/admin/tickets/:ticketId/reply", authenticateAdmin, (req, res) => {
    const { ticketId } = req.params;
    const { reply } = req.body;

    if (!reply) {
      return res.status(400).json({ error: "Reply message cannot be empty." });
    }

    const db = loadDB();
    const ticket = db.tickets.find(t => t.id === ticketId);
    if (!ticket) {
      return res.status(404).json({ error: "Support ticket not found." });
    }

    ticket.reply = String(reply).trim();
    ticket.status = "answered";
    saveDB(db);

    return res.json({ message: "Support ticket replied successfully.", ticket });
  });


  // ---------------- VITE FRONTEND MIDDLWARE AND PRODUCTION SERVING ----------------

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Bind to port 3000 and 0.0.0.0
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[KHMER BOOST SMM] Server operating on http://localhost:${PORT}`);
  });
}

startServer();
